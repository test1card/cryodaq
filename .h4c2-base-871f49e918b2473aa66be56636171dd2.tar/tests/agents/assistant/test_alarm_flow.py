"""Tests for AssistantLiveAgent alarm flow — Slice A end-to-end (mock Ollama)."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from cryodaq.agents.assistant.live.agent import AssistantConfig, AssistantLiveAgent, _format_age
from cryodaq.agents.assistant.live.context_builder import ContextBuilder
from cryodaq.agents.assistant.live.output_router import OutputRouter
from cryodaq.agents.assistant.shared.audit import AuditLogger
from cryodaq.agents.assistant.shared.ollama_client import GenerationResult, OllamaUnavailableError
from cryodaq.core.event_bus import EngineEvent, EventBus

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _alarm_event(
    alarm_id: str = "test_alarm",
    level: str = "CRITICAL",  # v0.55.5 — proactive narrative is CRITICAL-only
    experiment_id: str | None = "exp-001",
) -> EngineEvent:
    return EngineEvent(
        event_type="alarm_fired",
        timestamp=datetime(2026, 5, 1, 12, 0, 0, tzinfo=UTC),
        payload={
            "alarm_id": alarm_id,
            "level": level,
            "channels": ["T1", "T2"],
            "values": {"T1": 4.5, "T2": 4.8},
            "message": "Temperature above threshold",
        },
        experiment_id=experiment_id,
    )


def _make_config(**overrides) -> AssistantConfig:
    cfg = AssistantConfig(
        enabled=True,
        max_concurrent_inferences=1,
        max_calls_per_hour=60,
        alarm_min_level="WARNING",
        output_telegram=True,
        output_operator_log=True,
        output_gui_insight=False,
        audit_enabled=False,
    )
    for k, v in overrides.items():
        setattr(cfg, k, v)
    return cfg


def _make_mock_ollama(text: str = "🤖 Тест: температура T1 4.5K выше порога.") -> MagicMock:
    ollama = AsyncMock()
    ollama.generate = AsyncMock(
        return_value=GenerationResult(
            text=text, tokens_in=80, tokens_out=25, latency_s=3.5, model="gemma4:e4b"
        )
    )
    ollama.close = AsyncMock()
    return ollama


def _make_mock_em() -> MagicMock:
    em = MagicMock()
    em.active_experiment_id = "exp-001"
    em.get_current_phase = MagicMock(return_value="COOL")
    em.get_phase_history = MagicMock(return_value=[])
    return em


def _make_context_builder(em) -> ContextBuilder:
    reader = MagicMock()
    return ContextBuilder(reader, em)


def _make_audit(tmp_path: Path) -> AuditLogger:
    return AuditLogger(tmp_path / "audit", enabled=False)


def _make_output_router(telegram=None, event_logger=None, event_bus=None) -> OutputRouter:
    if telegram is None:
        telegram = AsyncMock()
        telegram._send_to_all = AsyncMock()
    if event_logger is None:
        event_logger = AsyncMock()
        event_logger.log_event = AsyncMock()
    if event_bus is None:
        event_bus = EventBus()
    return OutputRouter(
        telegram_bot=telegram,
        event_logger=event_logger,
        event_bus=event_bus,
    )


def _make_agent(
    *,
    config: AssistantConfig | None = None,
    ollama=None,
    telegram=None,
    event_logger=None,
    tmp_path: Path,
) -> tuple[AssistantLiveAgent, EventBus]:
    bus = EventBus()
    cfg = config or _make_config()
    em = _make_mock_em()
    ctx = _make_context_builder(em)
    audit = _make_audit(tmp_path)
    router = _make_output_router(telegram=telegram, event_logger=event_logger, event_bus=bus)
    agent = AssistantLiveAgent(
        config=cfg,
        event_bus=bus,
        ollama_client=ollama or _make_mock_ollama(),
        context_builder=ctx,
        audit_logger=audit,
        output_router=router,
    )
    return agent, bus


# ---------------------------------------------------------------------------
# AssistantConfig
# ---------------------------------------------------------------------------


def test_config_defaults() -> None:
    cfg = AssistantConfig()
    assert cfg.enabled is True
    assert cfg.alarm_min_level == "WARNING"
    assert cfg.max_concurrent_inferences == 2
    assert cfg.slice_a_notification is True
    assert cfg.slice_b_suggestion is False


def test_config_from_dict() -> None:
    raw = {
        "enabled": True,
        "ollama": {
            "base_url": "http://localhost:11434",
            "default_model": "gemma4:e4b",
            "timeout_s": 30,
        },
        "rate_limit": {"max_calls_per_hour": 60, "max_concurrent_inferences": 2},
        "triggers": {"alarm_fired": {"min_level": "WARNING"}},
        "outputs": {"telegram": True, "operator_log": True, "gui_insight_panel": True},
        "slices": {"a_notification": True, "b_suggestion": False},
        "audit": {"enabled": True, "retention_days": 90},
    }
    cfg = AssistantConfig.from_dict(raw)
    assert cfg.enabled is True
    assert cfg.default_model == "gemma4:e4b"
    assert cfg.alarm_min_level == "WARNING"
    assert cfg.max_calls_per_hour == 60


# ---------------------------------------------------------------------------
# AssistantLiveAgent — start / stop
# ---------------------------------------------------------------------------


async def test_agent_start_subscribes_to_bus(tmp_path: Path) -> None:
    agent, bus = _make_agent(tmp_path=tmp_path)
    await agent.start()
    assert bus.subscriber_count == 1
    await agent.stop()
    assert bus.subscriber_count == 0


async def test_agent_disabled_does_not_subscribe(tmp_path: Path) -> None:
    agent, bus = _make_agent(config=_make_config(enabled=False), tmp_path=tmp_path)
    await agent.start()
    assert bus.subscriber_count == 0
    await agent.stop()


# ---------------------------------------------------------------------------
# AssistantLiveAgent — alarm_fired → LLM → dispatch
# ---------------------------------------------------------------------------


async def test_alarm_fired_triggers_ollama_generate(tmp_path: Path) -> None:
    done = asyncio.Event()
    base_result = GenerationResult(
        text="🤖 Тест: T1 4.5K выше порога.", tokens_in=80, tokens_out=25,
        latency_s=3.5, model="gemma4:e4b",
    )

    async def _generate_and_signal(*args, **kwargs):
        done.set()
        return base_result

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=_generate_and_signal)
    ollama.close = AsyncMock()
    agent, bus = _make_agent(ollama=ollama, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    await asyncio.wait_for(done.wait(), timeout=2.0)

    ollama.generate.assert_awaited_once()
    await agent.stop()


async def test_alarm_fired_dispatches_to_telegram(tmp_path: Path) -> None:
    done = asyncio.Event()
    telegram = AsyncMock()

    async def _send_and_signal(*args, **kwargs):
        done.set()

    telegram._send_to_all = AsyncMock(side_effect=_send_and_signal)
    agent, bus = _make_agent(telegram=telegram, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    await asyncio.wait_for(done.wait(), timeout=2.0)

    telegram._send_to_all.assert_awaited_once()
    sent_text = telegram._send_to_all.call_args[0][0]
    assert "🤖 Гемма:" in sent_text
    await agent.stop()


async def test_alarm_fired_dispatches_to_operator_log(tmp_path: Path) -> None:
    done = asyncio.Event()
    event_logger = AsyncMock()

    async def _log_and_signal(*args, **kwargs):
        done.set()

    event_logger.log_event = AsyncMock(side_effect=_log_and_signal)
    agent, bus = _make_agent(event_logger=event_logger, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    await asyncio.wait_for(done.wait(), timeout=2.0)

    event_logger.log_event.assert_awaited_once()
    args = event_logger.log_event.call_args
    assert args[0][0] == "assistant"
    await agent.stop()


async def test_info_level_alarm_not_handled(tmp_path: Path) -> None:
    ollama = _make_mock_ollama()
    agent, bus = _make_agent(
        config=_make_config(alarm_min_level="WARNING"), ollama=ollama, tmp_path=tmp_path
    )
    # Direct predicate check: INFO is below the CRITICAL threshold hardcoded in
    # _should_handle; no EventBus round-trip needed.
    event = _alarm_event(level="INFO")
    assert agent._should_handle(event) is False, (
        "INFO-level alarm must be filtered by _should_handle before reaching Ollama"
    )


async def test_critical_level_alarm_is_handled(tmp_path: Path) -> None:
    done = asyncio.Event()
    base_result = GenerationResult(
        text="🤖 Тест: T1 4.5K выше порога.", tokens_in=80, tokens_out=25,
        latency_s=3.5, model="gemma4:e4b",
    )

    async def _generate_and_signal(*args, **kwargs):
        done.set()
        return base_result

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=_generate_and_signal)
    ollama.close = AsyncMock()
    agent, bus = _make_agent(ollama=ollama, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event(level="CRITICAL"))
    await asyncio.wait_for(done.wait(), timeout=2.0)

    ollama.generate.assert_awaited_once()
    await agent.stop()


# ---------------------------------------------------------------------------
# AssistantLiveAgent — error resilience
# ---------------------------------------------------------------------------


async def test_ollama_unavailable_does_not_crash_agent(tmp_path: Path) -> None:
    done = asyncio.Event()

    async def _raise_and_signal(*args, **kwargs):
        done.set()
        raise OllamaUnavailableError("connection refused")

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=_raise_and_signal)
    ollama.close = AsyncMock()
    agent, bus = _make_agent(ollama=ollama, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    await asyncio.wait_for(done.wait(), timeout=2.0)

    assert agent._task is not None
    assert not agent._task.done()
    await agent.stop()


async def test_rate_limit_drops_excess_calls(tmp_path: Path) -> None:
    first_done = asyncio.Event()
    second_dropped = asyncio.Event()
    base_result = GenerationResult(
        text="🤖 Тест.", tokens_in=10, tokens_out=5, latency_s=0.1, model="gemma4:e4b",
    )

    async def _generate_and_signal(*args, **kwargs):
        first_done.set()
        return base_result

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=_generate_and_signal)
    ollama.close = AsyncMock()
    agent, bus = _make_agent(
        config=_make_config(max_calls_per_hour=1), ollama=ollama, tmp_path=tmp_path
    )

    # Wrap _check_rate_limit: after the first allowed call, signal when the
    # second event is dropped (rate limit exceeded path).
    original_check = agent._check_rate_limit
    call_count = [0]

    def _patched_check():
        result = original_check()
        if not result:
            # This is the drop path — the second event has been processed and rejected.
            second_dropped.set()
        else:
            call_count[0] += 1
        return result

    agent._check_rate_limit = _patched_check

    await agent.start()

    await bus.publish(_alarm_event(alarm_id="a1"))
    await bus.publish(_alarm_event(alarm_id="a2"))
    # Wait for the first call to complete (so the timestamp is recorded).
    await asyncio.wait_for(first_done.wait(), timeout=2.0)
    # Wait for the second event to be processed and dropped by the rate limiter.
    await asyncio.wait_for(second_dropped.wait(), timeout=2.0)

    assert ollama.generate.await_count == 1
    await agent.stop()


async def test_alarm_fired_enabled_false_skips_handling(tmp_path: Path) -> None:
    ollama = _make_mock_ollama()
    agent, bus = _make_agent(
        config=_make_config(alarm_fired_enabled=False), ollama=ollama, tmp_path=tmp_path
    )
    # Direct predicate check: alarm_fired_enabled=False → _should_handle returns False.
    event = _alarm_event(level="CRITICAL")
    assert agent._should_handle(event) is False, (
        "alarm_fired_enabled=False must be filtered by _should_handle"
    )


async def test_truncated_response_skips_dispatch(tmp_path: Path) -> None:
    from cryodaq.agents.assistant.shared.ollama_client import GenerationResult

    generate_called = asyncio.Event()

    async def _generate_truncated(*args, **kwargs):
        generate_called.set()
        return GenerationResult(
            text="", tokens_in=0, tokens_out=0, latency_s=30.0, model="gemma4:e4b", truncated=True
        )

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=_generate_truncated)
    ollama.close = AsyncMock()
    telegram = AsyncMock()
    telegram._send_to_all = AsyncMock()
    agent, bus = _make_agent(ollama=ollama, telegram=telegram, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    # Wait until generate was actually called (handler ran), then assert no dispatch.
    await asyncio.wait_for(generate_called.wait(), timeout=2.0)
    ollama.generate.assert_awaited_once()

    telegram._send_to_all.assert_not_awaited()
    await agent.stop()


async def test_handler_tasks_cancelled_on_stop(tmp_path: Path) -> None:
    started = asyncio.Event()
    blocked = asyncio.Event()

    async def slow_generate(*args, **kwargs):
        started.set()
        await blocked.wait()
        return GenerationResult(text="ok", tokens_in=5, tokens_out=5, latency_s=1.0, model="m")

    from cryodaq.agents.assistant.shared.ollama_client import GenerationResult

    ollama = AsyncMock()
    ollama.generate = AsyncMock(side_effect=slow_generate)
    ollama.close = AsyncMock()
    agent, bus = _make_agent(ollama=ollama, tmp_path=tmp_path)
    await agent.start()

    await bus.publish(_alarm_event())
    await asyncio.wait_for(started.wait(), timeout=1.0)

    assert len(agent._handler_tasks) > 0
    await agent.stop()
    assert len(agent._handler_tasks) == 0


# ---------------------------------------------------------------------------
# AssistantLiveAgent — experiment_finalize handler
# ---------------------------------------------------------------------------


async def test_experiment_finalize_handler_dispatches(tmp_path: Path) -> None:
    done = asyncio.Event()
    telegram = AsyncMock()
    telegram._send_to_all = AsyncMock()
    event_logger = AsyncMock()

    async def _log_and_signal(*args, **kwargs):
        done.set()

    event_logger.log_event = AsyncMock(side_effect=_log_and_signal)
    ollama = _make_mock_ollama("Эксперимент завершён: продолжительность 2ч, всё штатно.")
    cfg = _make_config(
        output_telegram=True,
        output_operator_log=True,
        output_gui_insight=True,
        experiment_finalize_enabled=True,
    )
    agent, bus = _make_agent(
        config=cfg, ollama=ollama, telegram=telegram, event_logger=event_logger, tmp_path=tmp_path
    )
    insight_q = await bus.subscribe("test_exp_insight", maxsize=10)
    await agent.start()

    event = EngineEvent(
        event_type="experiment_finalize",
        timestamp=datetime(2026, 5, 1, 14, 0, 0, tzinfo=UTC),
        payload={
            "action": "experiment_finalize",
            "experiment": {"experiment_id": "exp-001", "name": "Тест охлаждения"},
        },
        experiment_id="exp-001",
    )
    await bus.publish(event)
    await asyncio.wait_for(done.wait(), timeout=2.0)

    ollama.generate.assert_awaited_once()
    call_kwargs = ollama.generate.call_args[1]
    assert call_kwargs["system"] is not None
    assert "эксперимент" in call_kwargs["system"].lower()

    telegram._send_to_all.assert_awaited_once()
    event_logger.log_event.assert_awaited_once()

    insight_events = []
    while not insight_q.empty():
        e = insight_q.get_nowait()
        if e.event_type == "assistant_insight":
            insight_events.append(e)
    assert len(insight_events) == 1
    assert insight_events[0].payload["trigger_event_type"] == "experiment_finalize"

    bus.unsubscribe("test_exp_insight")
    await agent.stop()


async def test_experiment_finalize_disabled_skips_handling(tmp_path: Path) -> None:
    ollama = _make_mock_ollama()
    agent, bus = _make_agent(
        config=_make_config(experiment_finalize_enabled=False), ollama=ollama, tmp_path=tmp_path
    )
    event = EngineEvent(
        event_type="experiment_finalize",
        timestamp=datetime(2026, 5, 1, 14, 0, 0, tzinfo=UTC),
        payload={"action": "experiment_finalize", "experiment": {}},
        experiment_id="exp-001",
    )
    # Direct predicate check: experiment_finalize_enabled=False → filtered.
    assert agent._should_handle(event) is False, (
        "experiment_finalize_enabled=False must be filtered by _should_handle"
    )


# ---------------------------------------------------------------------------
# AssistantLiveAgent — sensor_anomaly_critical handler
# ---------------------------------------------------------------------------


async def test_sensor_anomaly_critical_proactive_disabled_v0_55_5(tmp_path: Path) -> None:
    """v0.55.5 — sensor_anomaly_critical no longer triggers Гемма proactive.

    Sensor health is operator-visible on the GUI Diagnostics tab and folded
    into the hourly digest; proactive LLM narrative on every diagnostic
    CRITICAL was creating Telegram noise without operator value.
    """
    telegram = AsyncMock()
    telegram._send_to_all = AsyncMock()
    event_logger = AsyncMock()
    event_logger.log_event = AsyncMock()
    ollama = _make_mock_ollama("ignored")
    cfg = _make_config(
        output_telegram=True,
        output_operator_log=True,
        output_gui_insight=True,
        sensor_anomaly_critical_enabled=True,  # legacy flag — superseded by v0.55.5 filter
    )
    agent, bus = _make_agent(
        config=cfg, ollama=ollama, telegram=telegram, event_logger=event_logger, tmp_path=tmp_path
    )
    event = EngineEvent(
        event_type="sensor_anomaly_critical",
        timestamp=datetime(2026, 5, 1, 14, 5, 0, tzinfo=UTC),
        payload={
            "alarm_id": "diag:T1",
            "level": "CRITICAL",
            "channels": ["T1"],
            "values": {"T1": 4.2},
            "message": "Excessive noise detected",
        },
        experiment_id="exp-001",
    )
    # v0.55.5: _should_handle unconditionally returns False for sensor_anomaly_critical
    # regardless of the legacy sensor_anomaly_critical_enabled flag.
    assert agent._should_handle(event) is False, (
        "sensor_anomaly_critical must always be filtered by _should_handle (v0.55.5)"
    )


async def test_sensor_anomaly_disabled_skips_handling(tmp_path: Path) -> None:
    ollama = _make_mock_ollama()
    agent, bus = _make_agent(
        config=_make_config(sensor_anomaly_critical_enabled=False),
        ollama=ollama,
        tmp_path=tmp_path,
    )
    event = EngineEvent(
        event_type="sensor_anomaly_critical",
        timestamp=datetime(2026, 5, 1, 14, 5, 0, tzinfo=UTC),
        payload={"alarm_id": "diag:T1", "level": "CRITICAL", "channels": ["T1"], "values": {}},
        experiment_id=None,
    )
    # _should_handle returns False unconditionally for this event type (v0.55.5).
    assert agent._should_handle(event) is False, (
        "sensor_anomaly_critical must be filtered by _should_handle"
    )


# ---------------------------------------------------------------------------
# AssistantLiveAgent — shift_handover_request handler
# ---------------------------------------------------------------------------


async def test_shift_handover_handler_dispatches(tmp_path: Path) -> None:
    done = asyncio.Event()
    telegram = AsyncMock()
    telegram._send_to_all = AsyncMock()
    event_logger = AsyncMock()

    async def _log_and_signal(*args, **kwargs):
        done.set()

    event_logger.log_event = AsyncMock(side_effect=_log_and_signal)
    ollama = _make_mock_ollama("Сводка смены: температура стабильна, эксперимент в норме.")
    cfg = _make_config(
        output_telegram=True,
        output_operator_log=True,
        output_gui_insight=True,
        shift_handover_request_enabled=True,
    )
    agent, bus = _make_agent(
        config=cfg, ollama=ollama, telegram=telegram, event_logger=event_logger, tmp_path=tmp_path
    )
    insight_q = await bus.subscribe("test_sh_insight", maxsize=10)
    await agent.start()

    event = EngineEvent(
        event_type="shift_handover_request",
        timestamp=datetime(2026, 5, 1, 20, 0, 0, tzinfo=UTC),
        payload={"requested_by": "Иванов", "shift_duration_h": 8},
        experiment_id="exp-001",
    )
    await bus.publish(event)
    await asyncio.wait_for(done.wait(), timeout=2.0)

    ollama.generate.assert_awaited_once()
    call_kwargs = ollama.generate.call_args[1]
    assert call_kwargs["system"] is not None
    assert "смен" in call_kwargs["system"].lower()

    telegram._send_to_all.assert_awaited_once()
    event_logger.log_event.assert_awaited_once()

    insight_events = []
    while not insight_q.empty():
        e = insight_q.get_nowait()
        if e.event_type == "assistant_insight":
            insight_events.append(e)
    assert len(insight_events) == 1
    assert insight_events[0].payload["trigger_event_type"] == "shift_handover_request"

    bus.unsubscribe("test_sh_insight")
    await agent.stop()


async def test_shift_handover_disabled_skips_handling(tmp_path: Path) -> None:
    ollama = _make_mock_ollama()
    agent, bus = _make_agent(
        config=_make_config(shift_handover_request_enabled=False),
        ollama=ollama,
        tmp_path=tmp_path,
    )
    event = EngineEvent(
        event_type="shift_handover_request",
        timestamp=datetime(2026, 5, 1, 20, 0, 0, tzinfo=UTC),
        payload={"requested_by": "Иванов", "shift_duration_h": 8},
        experiment_id=None,
    )
    # Direct predicate check: shift_handover_request_enabled=False → filtered.
    assert agent._should_handle(event) is False, (
        "shift_handover_request_enabled=False must be filtered by _should_handle"
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def test_format_age_none() -> None:
    assert _format_age(None) == "неизвестно"


def test_format_age_seconds() -> None:
    assert _format_age(45) == "45с"


def test_format_age_minutes() -> None:
    assert _format_age(150) == "2м 30с"


def test_format_age_hours() -> None:
    assert _format_age(7260) == "2ч 1м"
