"""AlarmEngine v2 — физически обоснованные алармы с composite, rate, stale conditions.

Компоненты:
  AlarmEvent       — событие срабатывания аларма
  PhaseProvider    — интерфейс для получения текущей фазы эксперимента
  SetpointProvider — интерфейс для получения setpoints
  AlarmEvaluator   — вычисляет условие аларма → AlarmEvent | None
  AlarmStateManager — управляет состоянием (active/cleared), гистерезис, dedup

Физическое обоснование: docs/alarm_tz_physics_v3.md
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import time
from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from cryodaq.core.channel_state import ChannelStateTracker
    from cryodaq.core.rate_estimator import RateEstimator

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# AlarmEvent
# ---------------------------------------------------------------------------


@dataclass
class AlarmEvent:
    """Событие срабатывания аларма."""

    alarm_id: str
    level: str  # "INFO" | "WARNING" | "CRITICAL"
    message: str
    triggered_at: float  # unix timestamp
    channels: list[str]  # каналы-участники
    values: dict[str, float]  # channel → значение на момент срабатывания
    acknowledged: bool = False
    acknowledged_at: float = 0.0
    acknowledged_by: str = ""


class AlarmSnapshotUnavailableError(RuntimeError):
    """The active alarm set cannot be represented by the closed snapshot schema."""

    def __init__(self) -> None:
        super().__init__("alarm snapshot unavailable")


@dataclass(frozen=True)
class AlarmCanonicalSnapshot:
    """One synchronous revision, minimal active mapping, and canonical token."""

    state_revision: int
    active: dict[str, dict[str, Any]]
    state_token: str


_ALARM_SNAPSHOT_MAX_ACTIVE = 128
_ALARM_SNAPSHOT_MAX_CHANNELS = 64
_ALARM_SNAPSHOT_MAX_TEXT = 256
_ALARM_SNAPSHOT_MAX_CANONICAL_BYTES = 60 * 1024
_ALARM_LEVELS = frozenset({"INFO", "WARNING", "CRITICAL"})


def _copy_alarm_event(event: AlarmEvent) -> AlarmEvent:
    """Return a detached AlarmEvent, including both mutable containers."""
    return AlarmEvent(
        alarm_id=event.alarm_id,
        level=event.level,
        message=event.message,
        triggered_at=event.triggered_at,
        channels=list(event.channels),
        values=dict(event.values),
        acknowledged=event.acknowledged,
        acknowledged_at=event.acknowledged_at,
        acknowledged_by=event.acknowledged_by,
    )


# ---------------------------------------------------------------------------
# AlarmTransition
# ---------------------------------------------------------------------------

AlarmTransition = Literal["TRIGGERED", "CLEARED"]


# ---------------------------------------------------------------------------
# Provider protocols (duck-typed, без runtime Protocol overhead)
# ---------------------------------------------------------------------------


class PhaseProvider:
    """Базовый провайдер фазы — заглушка для тестов."""

    def get_current_phase(self) -> str | None:
        return None

    def get_phase_elapsed_s(self) -> float:
        return 0.0


class SetpointProvider:
    """Базовый провайдер setpoints — заглушка для тестов."""

    def __init__(self, defaults: dict[str, float] | None = None) -> None:
        self._defaults: dict[str, float] = defaults or {}

    def get(self, key: str) -> float:
        return self._defaults.get(key, 0.0)


# ---------------------------------------------------------------------------
# AlarmEvaluator
# ---------------------------------------------------------------------------

_DEFAULT_RATE_WINDOW_S = 120.0


class AlarmEvaluator:
    """Вычисляет условие аларма по текущему состоянию системы.

    Параметры
    ----------
    state:
        ChannelStateTracker с текущими значениями каналов.
    rate:
        RateEstimator с оценками dX/dt.
    phase_provider:
        Провайдер текущей фазы эксперимента.
    setpoint_provider:
        Провайдер setpoints.
    """

    def __init__(
        self,
        state: ChannelStateTracker,
        rate: RateEstimator,
        phase_provider: PhaseProvider,
        setpoint_provider: SetpointProvider,
    ) -> None:
        self._state = state
        self._rate = rate
        self._phase = phase_provider
        self._setpoint = setpoint_provider

    def evaluate(
        self,
        alarm_id: str,
        alarm_config: dict[str, Any],
        *,
        is_active: bool = False,
        active_channels: frozenset[str] | None = None,
    ) -> AlarmEvent | None:
        """Проверить одну alarm-конфигурацию. None = не сработал.

        Parameters
        ----------
        is_active:
            True if this alarm is currently active in AlarmStateManager.
            Used by threshold evaluator to apply hysteresis deadband: alarm
            stays active until value clears ``threshold ± hysteresis``.
        active_channels:
            Set of channels that triggered the current active alarm event.
            When provided, hysteresis deadband is only applied to these
            channels — prevents a non-triggering channel from keeping a
            multi-channel alarm alive incorrectly.
        """
        alarm_type = alarm_config.get("alarm_type")
        try:
            if alarm_type == "threshold":
                return self._eval_threshold(
                    alarm_id,
                    alarm_config,
                    is_active=is_active,
                    active_channels=active_channels,
                )
            elif alarm_type == "composite":
                return self._eval_composite(alarm_id, alarm_config)
            elif alarm_type == "rate":
                return self._eval_rate(alarm_id, alarm_config)
            elif alarm_type == "stale":
                return self._eval_stale(alarm_id, alarm_config)
            else:
                logger.warning("Неизвестный alarm_type=%r для %s", alarm_type, alarm_id)
                return None
        except Exception as exc:
            logger.error("Ошибка evaluate %s: %s", alarm_id, exc, exc_info=True)
            return None

    # ------------------------------------------------------------------
    # threshold
    # ------------------------------------------------------------------

    def _eval_threshold(
        self,
        alarm_id: str,
        cfg: dict,
        *,
        is_active: bool = False,
        active_channels: frozenset[str] | None = None,
    ) -> AlarmEvent | None:
        check = cfg.get("check", "above")
        channels = self._resolve_channels(cfg)
        level = cfg.get("level", "WARNING")
        message_tmpl = cfg.get("message", f"Alarm {alarm_id}")
        hysteresis: float | None = cfg.get("hysteresis")

        for ch in channels:
            triggered, value = self._check_threshold_channel(ch, check, cfg)
            if triggered:
                msg = self._format_message(message_tmpl, channel=ch, value=value)
                return AlarmEvent(
                    alarm_id=alarm_id,
                    level=level,
                    message=msg,
                    triggered_at=time.time(),
                    channels=[ch],
                    values={ch: value},
                )
            # Hysteresis deadband (F21): if alarm is currently active, keep it
            # active until value clears threshold ± hysteresis margin. Returns a
            # "keep active" event that AlarmStateManager deduplicates (no new
            # TRIGGERED transition, no re-notification).
            # active_channels guard: only apply deadband to the channel(s) that
            # originally triggered the alarm; prevents a non-triggering channel
            # from keeping a multi-channel alarm alive indefinitely.
            if is_active and hysteresis is not None and check in ("above", "below"):
                if active_channels is not None and ch not in active_channels:
                    continue  # channel did not trigger this alarm; skip deadband
                threshold = cfg.get("threshold", 0.0)
                in_deadband = (check == "above" and value >= threshold - hysteresis) or (
                    check == "below" and value <= threshold + hysteresis
                )
                if in_deadband:
                    msg = self._format_message(message_tmpl, channel=ch, value=value)
                    return AlarmEvent(
                        alarm_id=alarm_id,
                        level=level,
                        message=msg,
                        triggered_at=time.time(),
                        channels=[ch],
                        values={ch: value},
                    )
        return None

    def _check_threshold_channel(self, channel: str, check: str, cfg: dict) -> tuple[bool, float]:
        """Возвращает (сработал, значение)."""
        if check == "fault_count_in_window":
            count = self._state.get_fault_count(channel)
            min_count = cfg.get("min_fault_count", 1)
            return count >= min_count, float(count)

        state = self._state.get(channel)
        if state is None:
            return False, 0.0
        value = state.value

        if check == "above":
            return value > cfg["threshold"], value
        elif check == "below":
            return value < cfg["threshold"], value
        elif check == "outside_range":
            r = cfg["range"]
            return (value < r[0] or value > r[1]), value
        elif check == "deviation_from_setpoint":
            setpoint = self._setpoint.get(cfg["setpoint_source"])
            return abs(value - setpoint) > cfg["threshold"], value
        else:
            logger.warning("Неизвестный threshold check=%r", check)
            return False, value

    # ------------------------------------------------------------------
    # composite
    # ------------------------------------------------------------------

    def _eval_composite(self, alarm_id: str, cfg: dict) -> AlarmEvent | None:
        operator = cfg.get("operator", "AND")
        conditions = cfg.get("conditions", [])
        level = cfg.get("level", "WARNING")
        message = cfg.get("message", f"Alarm {alarm_id}")

        results = [self._eval_condition(c) for c in conditions]

        if operator == "AND":
            fired = all(results)
        elif operator == "OR":
            fired = any(results)
        else:
            logger.warning("Неизвестный composite operator=%r", operator)
            return None

        if not fired:
            return None

        # Collect channels and values
        channels: list[str] = []
        values: dict[str, float] = {}
        for cond in conditions:
            for ch in self._resolve_channels(cond):
                state = self._state.get(ch)
                if state and ch not in channels:
                    channels.append(ch)
                    values[ch] = state.value

        return AlarmEvent(
            alarm_id=alarm_id,
            level=level,
            message=str(message),
            triggered_at=time.time(),
            channels=channels,
            values=values,
        )

    def _eval_condition(self, cond: dict) -> bool:
        """Вычислить одно sub-condition → bool."""
        check = cond.get("check", "above")

        if check == "any_below":
            channels = self._resolve_channels(cond)
            threshold = cond["threshold"]
            return any((s := self._state.get(ch)) is not None and s.value < threshold for ch in channels)

        elif check == "any_above":
            channels = self._resolve_channels(cond)
            threshold = cond["threshold"]
            return any((s := self._state.get(ch)) is not None and s.value > threshold for ch in channels)

        elif check == "above":
            ch = cond.get("channel")
            if not ch:
                return False
            # Special: phase_elapsed_s
            if ch == "phase_elapsed_s":
                elapsed = self._phase.get_phase_elapsed_s()
                return elapsed > cond["threshold"]
            state = self._state.get(ch)
            return state is not None and state.value > cond["threshold"]

        elif check == "below":
            ch = cond.get("channel")
            if not ch:
                return False
            state = self._state.get(ch)
            return state is not None and state.value < cond["threshold"]

        elif check == "rate_above":
            ch = cond.get("channel")
            if not ch:
                return False
            window = cond.get("rate_window_s", _DEFAULT_RATE_WINDOW_S)
            rate = self._rate.get_rate_custom_window(ch, window)
            return rate is not None and rate > cond["threshold"]

        elif check == "rate_below":
            ch = cond.get("channel")
            if not ch:
                return False
            window = cond.get("rate_window_s", _DEFAULT_RATE_WINDOW_S)
            rate = self._rate.get_rate_custom_window(ch, window)
            return rate is not None and rate < cond["threshold"]

        elif check == "rate_near_zero":
            ch = cond.get("channel")
            if not ch:
                return False
            window = cond.get("rate_window_s", _DEFAULT_RATE_WINDOW_S)
            rate = self._rate.get_rate_custom_window(ch, window)
            rate_threshold = cond.get("rate_threshold", 0.1)
            return rate is not None and abs(rate) < rate_threshold

        else:
            logger.warning("Неизвестный composite condition check=%r", check)
            return False

    # ------------------------------------------------------------------
    # rate
    # ------------------------------------------------------------------

    def _eval_rate(self, alarm_id: str, cfg: dict) -> AlarmEvent | None:
        channels = self._resolve_channels(cfg)
        check = cfg.get("check", "rate_above")
        window = cfg.get("rate_window_s", _DEFAULT_RATE_WINDOW_S)
        level = cfg.get("level", "WARNING")
        message_tmpl = cfg.get("message", f"Alarm {alarm_id}")

        for ch in channels:
            rate = self._rate.get_rate_custom_window(ch, window)
            if rate is None:
                continue

            fired = False
            if check == "rate_above":
                fired = rate > cfg["threshold"]
            elif check == "rate_below":
                fired = rate < cfg["threshold"]
            elif check == "rate_near_zero":
                fired = abs(rate) < cfg.get("rate_threshold", 0.1)
            elif check == "relative_rate_near_zero":
                state = self._state.get(ch)
                if state and state.value > 0:
                    rel_rate = abs(rate / state.value)
                    fired = rel_rate < cfg.get("rate_threshold", 0.01)

            if fired:
                # Check additional_condition if present
                add_cond = cfg.get("additional_condition")
                if add_cond and not self._eval_condition(add_cond):
                    continue

                msg = self._format_message(message_tmpl, channel=ch, value=rate)
                return AlarmEvent(
                    alarm_id=alarm_id,
                    level=level,
                    message=msg,
                    triggered_at=time.time(),
                    channels=[ch],
                    values={ch: rate},
                )
        return None

    # ------------------------------------------------------------------
    # stale
    # ------------------------------------------------------------------

    def _eval_stale(self, alarm_id: str, cfg: dict) -> AlarmEvent | None:
        timeout = cfg.get("timeout_s", 30.0)
        channels = self._resolve_channels(cfg)
        level = cfg.get("level", "WARNING")
        message_tmpl = cfg.get("message", "Stale data: {channel}")
        now = time.time()

        for ch in channels:
            state = self._state.get(ch)
            if state is None:
                # Канал никогда не получал данных — тоже stale (если есть данные вообще)
                continue
            if (now - state.timestamp) > timeout:
                msg = self._format_message(message_tmpl, channel=ch, value=0.0)
                return AlarmEvent(
                    alarm_id=alarm_id,
                    level=level,
                    message=msg,
                    triggered_at=now,
                    channels=[ch],
                    values={ch: now - state.timestamp},
                )
        return None

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _resolve_channels(self, cfg: dict) -> list[str]:
        """Раскрыть каналы из channel / channels / channel_group в config."""
        if "channels" in cfg:
            return list(cfg["channels"])
        if "channel" in cfg:
            ch = cfg["channel"]
            if ch != "phase_elapsed_s":
                return [ch]
        return []

    @staticmethod
    def _format_message(template: str, channel: str = "", value: float = 0.0) -> str:
        try:
            return template.format(channel=channel, value=value)
        except (KeyError, ValueError):
            return str(template)


# ---------------------------------------------------------------------------
# AlarmStateManager
# ---------------------------------------------------------------------------


@dataclass
class _AlarmRecord:
    event: AlarmEvent
    triggered_at: float
    notified: bool = False


class AlarmStateManager:
    """Управляет состоянием алармов: active/cleared, гистерезис, dedup, sustained.

    Атрибуты
    ----------
    _active: dict[alarm_id, AlarmEvent]
        Активные алармы.
    _sustained_since: dict[alarm_id, float]
        Время первого срабатывания условия (для sustained check).
    """

    def __init__(self) -> None:
        self._active: dict[str, AlarmEvent] = {}
        self._sustained_since: dict[str, float] = {}
        self._state_revision = 0
        # Ограниченный deque предотвращает утечку памяти при длительной работе.
        self._history: deque[dict] = deque(maxlen=1000)

    @property
    def state_revision(self) -> int:
        """Monotonic revision of the authoritative active-alarm state."""
        return self._state_revision

    def _mark_active_mutation(self) -> None:
        self._state_revision += 1

    def process(
        self,
        alarm_id: str,
        event: AlarmEvent | None,
        config: dict,
    ) -> AlarmTransition | None:
        """Обработать результат evaluate.

        Возвращает:
          "TRIGGERED" — аларм только что сработал (новый)
          "CLEARED"   — аларм только что снялся
          None        — состояние не изменилось
        """
        sustained_s = config.get("sustained_s")
        hysteresis = config.get("hysteresis")

        # --- Условие сработало ---
        if event is not None:
            if sustained_s is not None:
                # Sustained: условие должно держаться N секунд
                if alarm_id not in self._sustained_since:
                    self._sustained_since[alarm_id] = time.time()
                elapsed = time.time() - self._sustained_since[alarm_id]
                if elapsed < sustained_s:
                    return None  # Ещё не выдержали
                # Sustained выдержан — продолжаем вниз к активации
            else:
                # Сброс sustained_since если нет sustained
                self._sustained_since.pop(alarm_id, None)

            # Dedup: уже активен?
            if alarm_id in self._active:
                return None  # Уже активен, не re-notify

            stored_event = _copy_alarm_event(event)
            self._active[alarm_id] = stored_event
            self._mark_active_mutation()
            self._history.append(
                {
                    "alarm_id": alarm_id,
                    "transition": "TRIGGERED",
                    "at": stored_event.triggered_at,
                    "level": stored_event.level,
                    "message": stored_event.message,
                }
            )
            logger.info(
                "ALARM TRIGGERED: %s [%s] %s",
                alarm_id,
                stored_event.level,
                stored_event.message[:80],
            )
            return "TRIGGERED"

        # --- Условие НЕ сработало ---
        else:
            # Сброс sustained tracking
            self._sustained_since.pop(alarm_id, None)

            if alarm_id not in self._active:
                return None  # Уже не активен

            # Hysteresis: проверить что value вышло из зоны гистерезиса
            if hysteresis and not self._check_hysteresis_cleared(alarm_id, config, hysteresis):
                return None  # Ещё в зоне гистерезиса

            old_event = self._active.pop(alarm_id)
            self._mark_active_mutation()
            self._history.append(
                {
                    "alarm_id": alarm_id,
                    "transition": "CLEARED",
                    "at": time.time(),
                    "level": old_event.level,
                }
            )
            logger.info("ALARM CLEARED: %s", alarm_id)
            return "CLEARED"

    def _check_hysteresis_cleared(self, alarm_id: str, config: dict, hysteresis: Any) -> bool:
        """Always returns True — hysteresis is handled in AlarmEvaluator (F21).

        AlarmEvaluator._eval_threshold receives is_active=True when an alarm is
        active and returns a "keep active" AlarmEvent while the channel value is
        inside the deadband [threshold - hysteresis, threshold]. process() only
        receives event=None once the value has fully exited the deadband, so
        this guard is always safe to pass.
        """
        return True

    def get_active(self) -> dict[str, AlarmEvent]:
        """Текущие активные алармы as fully detached public copies."""
        return {alarm_id: _copy_alarm_event(event) for alarm_id, event in self._active.items()}

    def snapshot_active_canonical(self) -> AlarmCanonicalSnapshot:
        """Build the bounded privacy-minimal active snapshot without yielding.

        Validation failures deliberately collapse to one fixed domain error so
        transport adapters cannot expose hostile alarm content in diagnostics.
        """
        try:
            if len(self._active) > _ALARM_SNAPSHOT_MAX_ACTIVE:
                raise AlarmSnapshotUnavailableError

            active: dict[str, dict[str, Any]] = {}
            for alarm_id in sorted(self._active):
                event = self._active[alarm_id]
                self._validate_snapshot_text(alarm_id)
                if event.alarm_id != alarm_id:
                    raise AlarmSnapshotUnavailableError
                if type(event.level) is not str or event.level not in _ALARM_LEVELS:
                    raise AlarmSnapshotUnavailableError

                triggered_at = self._validate_snapshot_number(event.triggered_at)
                if type(event.channels) is not list:
                    raise AlarmSnapshotUnavailableError
                if len(event.channels) > _ALARM_SNAPSHOT_MAX_CHANNELS:
                    raise AlarmSnapshotUnavailableError
                channels: list[str] = []
                for channel in event.channels:
                    self._validate_snapshot_text(channel)
                    channels.append(channel)
                channels = sorted(set(channels))

                if type(event.acknowledged) is not bool:
                    raise AlarmSnapshotUnavailableError
                acknowledged_at: float | None = None
                if event.acknowledged:
                    acknowledged_at = self._validate_snapshot_number(event.acknowledged_at)

                active[alarm_id] = {
                    "level": event.level,
                    "triggered_at": triggered_at,
                    "channels": channels,
                    "acknowledged": event.acknowledged,
                    "acknowledged_at": acknowledged_at,
                }

            canonical = json.dumps(
                active,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode("utf-8")
            if len(canonical) > _ALARM_SNAPSHOT_MAX_CANONICAL_BYTES:
                raise AlarmSnapshotUnavailableError
            token = "sha256:" + hashlib.sha256(canonical).hexdigest()
            return AlarmCanonicalSnapshot(
                state_revision=self._state_revision,
                active=active,
                state_token=token,
            )
        except AlarmSnapshotUnavailableError:
            raise
        except (AttributeError, TypeError, ValueError, OverflowError, UnicodeError):
            raise AlarmSnapshotUnavailableError from None

    @staticmethod
    def _validate_snapshot_text(value: object) -> None:
        if type(value) is not str or not value or len(value) > _ALARM_SNAPSHOT_MAX_TEXT:
            raise AlarmSnapshotUnavailableError
        encoded = value.encode("utf-8")
        if len(encoded) > _ALARM_SNAPSHOT_MAX_TEXT or any(
            ord(character) < 32 or ord(character) == 127 for character in value
        ):
            raise AlarmSnapshotUnavailableError

    @staticmethod
    def _validate_snapshot_number(value: object) -> float:
        if type(value) not in (int, float):
            raise AlarmSnapshotUnavailableError
        result = float(value)
        if not math.isfinite(result) or result < 0:
            raise AlarmSnapshotUnavailableError
        return result

    def get_history(self, limit: int = 50) -> list[dict]:
        """История переходов (последние limit)."""
        items = list(self._history)
        return items[-limit:]

    def publish_diagnostic_alarm(
        self,
        channel_id: str,
        severity: Literal["warning", "critical"],
        age_seconds: float,
    ) -> AlarmEvent | None:
        """Publish a diagnostic-sourced alarm for a channel.

        Called by SensorDiagnosticsEngine when anomaly persists past threshold
        duration (F10). Creates an alarm in the same shape as rule-evaluated
        alarms — broker event, ACK tracking, history. Idempotent per channel_id:
        if an alarm for this channel is already active, this is a no-op.

        Returns the AlarmEvent on new trigger, None if already active.
        """
        alarm_id = f"diag:{channel_id}"
        level = severity.upper()

        if alarm_id in self._active:
            existing = self._active[alarm_id]
            # F22 severity-upgrade: WARNING→CRITICAL in-place on the existing AlarmEvent.
            # Safety: AlarmEvent is a plain mutable @dataclass (no frozen=True), so
            # field mutation is intentional. alarm_id is NOT changed — the routing key
            # stays stable, so ACK tracking and Telegram thread continuity are preserved.
            # Alternative (new alarm_id per severity) was rejected: creates duplicate
            # operator notifications for the same physical anomaly. SEVERITY_UPGRADED
            # history entry provides the audit trail.
            if level == "CRITICAL" and existing.level == "WARNING":
                existing.level = level
                existing.message = f"Sensor anomaly sustained {age_seconds:.0f}s: {channel_id}"
                self._mark_active_mutation()
                self._history.append(
                    {
                        "alarm_id": alarm_id,
                        "transition": "SEVERITY_UPGRADED",
                        "at": time.time(),
                        "level": level,
                        "message": existing.message,
                    }
                )
                logger.info(
                    "DIAGNOSTIC ALARM SEVERITY UPGRADED: %s WARNING→CRITICAL age=%.0fs",
                    alarm_id,
                    age_seconds,
                )
                return _copy_alarm_event(existing)
            return None

        event = AlarmEvent(
            alarm_id=alarm_id,
            level=level,
            message=f"Sensor anomaly sustained {age_seconds:.0f}s: {channel_id}",
            triggered_at=time.time(),
            channels=[channel_id],
            values={channel_id: age_seconds},
        )
        self._active[alarm_id] = event
        self._mark_active_mutation()
        self._history.append(
            {
                "alarm_id": alarm_id,
                "transition": "TRIGGERED",
                "at": event.triggered_at,
                "level": level,
                "message": event.message,
            }
        )
        logger.info(
            "DIAGNOSTIC ALARM TRIGGERED: %s [%s] age=%.0fs",
            alarm_id,
            level,
            age_seconds,
        )
        return _copy_alarm_event(event)

    def clear_diagnostic_alarm(self, channel_id: str) -> None:
        """Clear diagnostic alarm for channel when anomaly resolves.

        Called by SensorDiagnosticsEngine when channel status returns to ok.
        No-op if no active diagnostic alarm for this channel.
        """
        alarm_id = f"diag:{channel_id}"
        if alarm_id not in self._active:
            return
        self._active.pop(alarm_id)
        self._mark_active_mutation()
        self._history.append(
            {
                "alarm_id": alarm_id,
                "transition": "CLEARED",
                "at": time.time(),
                "level": "INFO",
            }
        )
        logger.info("DIAGNOSTIC ALARM CLEARED: %s", alarm_id)

    def acknowledge(self, alarm_id: str, *, operator: str = "", reason: str = "") -> dict | None:
        """Подтвердить аларм — записать факт подтверждения в историю.

        Аларм остаётся в _active до сброса по условию (CLEARED).
        Acknowledged означает: оператор видел и принял к сведению.

        Returns event dict on new acknowledgement (caller should publish),
        or None if alarm unknown or already acknowledged (idempotent no-op).
        """
        if alarm_id not in self._active:
            logger.warning("ALARM ACK IGNORED: %s not in active alarms", alarm_id)
            return None

        event = self._active[alarm_id]
        if event.acknowledged:
            logger.debug(
                "ALARM ACK NOOP: %s already acknowledged by %s",
                alarm_id,
                event.acknowledged_by or "—",
            )
            return None

        event.acknowledged = True
        event.acknowledged_at = time.time()
        event.acknowledged_by = operator
        self._mark_active_mutation()

        self._history.append(
            {
                "alarm_id": alarm_id,
                "transition": "ACKNOWLEDGED",
                "at": event.acknowledged_at,
                "level": event.level,
                "operator": operator,
                "reason": reason,
            }
        )
        logger.info(
            "ALARM ACKNOWLEDGED: %s by %s (reason: %s)",
            alarm_id,
            operator or "—",
            reason or "—",
        )
        return {
            "alarm_id": alarm_id,
            "acknowledged_at": event.acknowledged_at,
            "operator": operator,
            "reason": reason,
        }


def tick_alarm(
    alarm_cfg: Any,
    current_phase: str | None,
    evaluator: AlarmEvaluator,
    state_mgr: AlarmStateManager,
) -> tuple[AlarmEvent | None, str | None]:
    """Run one alarm through the phase-filter → evaluate → process pipeline.

    This is the per-alarm core of the engine's alarm-v2 tick loop, extracted so
    both the engine and tests exercise the *same* production logic (phase-filter
    suppression in particular). Returns ``(event, transition)``.

    When ``alarm_cfg.phase_filter`` excludes ``current_phase`` the alarm is
    cleared in the state manager and ``(None, None)`` is returned, signalling the
    caller to dispatch nothing — matching the engine's "out of phase → clear and
    skip" behaviour.
    """
    if alarm_cfg.phase_filter is not None and current_phase not in alarm_cfg.phase_filter:
        state_mgr.process(alarm_cfg.alarm_id, None, alarm_cfg.config)
        return None, None

    active_event = state_mgr.get_active().get(alarm_cfg.alarm_id)
    event = evaluator.evaluate(
        alarm_cfg.alarm_id,
        alarm_cfg.config,
        is_active=active_event is not None,
        active_channels=(frozenset(active_event.channels) if active_event is not None else None),
    )
    transition = state_mgr.process(alarm_cfg.alarm_id, event, alarm_cfg.config)
    return event, transition
