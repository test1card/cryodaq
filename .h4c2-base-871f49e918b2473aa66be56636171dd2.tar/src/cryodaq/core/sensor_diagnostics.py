"""SensorDiagnosticsEngine — мониторинг здоровья датчиков.

Read-only аналитика поверх ChannelStateTracker:
- noise (MAD-based, robust to outliers)
- drift (OLS slope)
- correlation (Pearson r внутри групп)
- health score (0-100)
"""

from __future__ import annotations

import logging
import math
import re
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import numpy as np

from cryodaq.core.rate_estimator import _ols_slope_per_min

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Channel classifier (Phase 2c user report)
# ---------------------------------------------------------------------------
#
# The sensor diagnostics panel was showing health=0 ("red") for ~20 channels
# that aren't physical sensors at all — analytics state, system metrics,
# Keithley derived values (V/I/R/P that are 0 when source is off). Operators
# spent time investigating "broken sensors" that were actually working
# computed/derived signals with no noise or drift physics.
#
# is_physical_sensor() returns True only for channels whose values come from
# a real measurement (cryogenic thermometer, vacuum gauge, etc). Health
# scoring only makes sense for those.

# Patterns for derived / computed / system channels — checked FIRST so they
# can pre-empt anything that looks like a physical name.
_DERIVED_CHANNEL_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"^system/"),
    re.compile(r"^analytics/"),
    re.compile(r"/smu[ab]/"),  # Keithley dual-channel derived metrics
    re.compile(r"^Keithley.*/(voltage|current|power|resistance)$"),
)

# Patterns for physical sensors — actual measurements with noise/drift
# physics. Accepts both Cyrillic Т (canonical, runtime convention) and Latin T
# (used in some test fixtures and legacy configs).
_PHYSICAL_SENSOR_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"^[ТT]\d+(\b|\s|/|$)"),  # T-prefixed cryo channels
    re.compile(r"/[ТT]\d+(\b|\s|/|$)"),  # …with instrument prefix
    re.compile(r"/pressure\b"),  # Vacuum gauges
    re.compile(r"/temperature\b"),  # Generic temperature sensors
    re.compile(r"VSP63D"),  # Thyracont vacuum gauge namespace
)


def is_physical_sensor(channel: str) -> bool:
    """Return True if a channel represents a physical sensor measurement.

    Physical sensors have noise floor and drift physics that make health
    scoring meaningful. Derived / computed / system channels do not and
    should be excluded from the sensor diagnostics panel's health column.

    Phase 2c user report: operators see ~20 red '0' health values for
    analytics/system/derived-Keithley channels and waste time investigating
    non-existent sensor faults.
    """
    if not channel:
        return False
    if any(p.search(channel) for p in _DERIVED_CHANNEL_PATTERNS):
        return False
    return any(p.search(channel) for p in _PHYSICAL_SENSOR_PATTERNS)


@dataclass
class ChannelDiagnostics:
    channel_id: str
    channel_name: str
    current_T: float
    noise_std: float  # MAD-based σ (K)
    noise_mK: float  # same in mK
    drift_rate: float  # K/min
    drift_mK_per_min: float  # same in mK/min
    outlier_count: int  # in outlier window
    correlation: float | None  # Pearson r with nearest neighbour in group
    health_score: int  # 0-100
    fault_flags: list[str] = field(default_factory=list)
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class DiagnosticsSummary:
    total_channels: int
    healthy: int  # health >= 80
    warning: int  # 50 <= health < 80
    critical: int  # health < 50
    worst_channel: str
    worst_score: int
    worst_flags: list[str] = field(default_factory=list)


@dataclass
class _AnomalyState:
    """Per-channel anomaly tracking state for alarm publishing (F10)."""

    channel_id: str
    first_anomaly_ts: float  # monotonic clock — when anomaly first started
    current_status: str  # "warning" | "critical"
    last_warning_published_ts: float | None = None
    last_critical_published_ts: float | None = None


def _health_to_status(health_score: int) -> str:
    """Map health score (0-100) to alarm severity string.

    Mapping: >=80 → ok, 50-79 → warning, <50 → critical.
    v0.55.2 A4: warm reference channels skip scoring entirely and
    return health_score=-1; treat that as "ok" so the alarm publisher
    does not fire spurious diagnostic alarms against the warm refs.
    Existing SensorDiagnosticsEngine uses health_score, not a status
    enum; this bridge derives status for F10 alarm-publishing logic.
    """
    if health_score < 0:
        return "ok"
    if health_score >= 80:
        return "ok"
    if health_score >= 50:
        return "warning"
    return "critical"


# ---------------------------------------------------------------------------
# Noise thresholds by temperature (DT-670 sensitivity zones)
# ---------------------------------------------------------------------------


def _get_noise_threshold(T: float) -> float:
    """Допустимый шум (K) для данной температуры DT-670."""
    if T < 30:
        return 0.02
    elif T < 100:
        return 0.05
    elif T < 200:
        return 0.1
    else:
        return 0.2


# ---------------------------------------------------------------------------
# Statistics helpers
# ---------------------------------------------------------------------------


def _mad_sigma(values: np.ndarray) -> float:
    """MAD-based estimate of σ: median(|x - median(x)|) × 1.4826."""
    if len(values) < 2:
        return float("nan")
    median = np.median(values)
    mad = np.median(np.abs(values - median))
    return float(mad * 1.4826)


def _pearson_r(x: np.ndarray, y: np.ndarray) -> float | None:
    """Pearson correlation. None if insufficient data or zero variance."""
    if len(x) < 10 or len(y) < 10 or len(x) != len(y):
        return None
    sx = np.std(x, ddof=0)
    sy = np.std(y, ddof=0)
    if sx == 0.0 or sy == 0.0:
        return None
    r = float(np.corrcoef(x, y)[0, 1])
    if math.isnan(r):
        return None
    return r


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------


class SensorDiagnosticsEngine:
    """Мониторинг здоровья датчиков. Read-only, работает поверх буферов данных."""

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        alarm_publisher: Any | None = None,
        warning_duration_s: float = 300.0,
        critical_duration_s: float = 900.0,
        cold_start_grace_s: float | None = None,
    ) -> None:
        cfg = config or {}
        thresholds = cfg.get("thresholds", {})

        self.noise_window_s: float = cfg.get("noise_window_s", 120)
        self.drift_window_s: float = cfg.get("drift_window_s", 600)
        self.corr_window_s: float = cfg.get("corr_window_s", 600)
        self.outlier_window_s: float = cfg.get("outlier_window_s", 300)
        self.outlier_sigma: float = thresholds.get("outlier_sigma", 5.0)
        self.drift_threshold: float = thresholds.get("drift_K_per_min", 0.1)
        self.corr_min: float = thresholds.get("correlation_min", 0.8)
        self.min_points: int = cfg.get("min_points", 10)

        # channel_id → deque of (timestamp_s, value)
        self._buffers: dict[str, deque[tuple[float, float]]] = {}
        # Max buffer size: drift window at 10 Hz + margin
        self._maxlen: int = max(500, int(max(self.drift_window_s, self.corr_window_s) * 10) + 200)

        # correlation_groups: group_name → list of channel_ids
        self._correlation_groups: dict[str, list[str]] = dict(cfg.get("correlation_groups", {}))
        # Reverse map: channel_id → group_name
        self._channel_to_group: dict[str, str] = {}
        for group_name, channels in self._correlation_groups.items():
            for ch in channels:
                self._channel_to_group[ch] = group_name

        # channel_id → display name
        self._channel_names: dict[str, str] = {}
        # channel_id → is_cold flag (cryogenic vs warm reference). v0.55.2
        # A4: warm reference channels (calibration, structural, vacuum
        # case) sit at room temperature and would be miscored as КРИТ if
        # passed through the cryogenic noise/drift thresholds. They are
        # skipped from health scoring entirely until per-group thresholds
        # land in v0.56+. Default `True` keeps the original behaviour for
        # any channel the engine forgets to declare.
        self._is_cold: dict[str, bool] = {}

        # Cached diagnostics
        self._diagnostics: dict[str, ChannelDiagnostics] = {}

        # F10 alarm publishing
        self._alarm_publisher = alarm_publisher
        self._warning_duration_s = warning_duration_s
        self._critical_duration_s = critical_duration_s
        self._anomaly_state: dict[str, _AnomalyState] = {}
        # F20 escalation cooldown: suppress re-notification within window after alarm cleared
        self._escalation_cooldown_s: float = cfg.get("escalation_cooldown_s", 0.0)
        self._channel_last_notified: dict[str, float] = {}
        # v0.55.5 — cold-start grace. Suppresses anomaly alarms for the
        # configured window after the engine declares itself started, so
        # the first noisy seconds of buffer fill / mock reseed don't fire
        # a flurry of false positives. Constructor argument wins over
        # config value so tests can override without a YAML round-trip.
        if cold_start_grace_s is None:
            self._cold_start_grace_s = float(cfg.get("cold_start_grace_s", 300.0))
        else:
            self._cold_start_grace_s = float(cold_start_grace_s)
        self._engine_started_mono: float | None = None

    def mark_engine_started(self) -> None:
        """Stamp the cold-start anchor; subsequent alarms wait out the grace."""
        self._engine_started_mono = time.monotonic()

    def _is_in_grace_period(self) -> bool:
        if self._engine_started_mono is None:
            return False
        if self._cold_start_grace_s <= 0:
            return False
        return (time.monotonic() - self._engine_started_mono) < self._cold_start_grace_s

    def set_channel_names(self, names: dict[str, str]) -> None:
        """Set display names for channels."""
        self._channel_names = dict(names)

    def set_channel_cold_map(self, cold_map: dict[str, bool]) -> None:
        """Tell the engine which channels are cryogenic.

        Channels with ``is_cold=False`` (warm references — calibration,
        flange, vacuum case, structural) are excluded from health
        scoring; the cryogenic noise/drift thresholds make no sense at
        room temperature. Missing entries default to True (cold) so an
        unconfigured channel still gets scored.
        """
        self._is_cold = dict(cold_map)

    def _is_channel_cold(self, channel_id: str) -> bool:
        """Return True iff the channel should be scored as cryogenic.

        Looks up both the full and short channel IDs so callers can
        push readings as "Т1" or "Т1 Криостат вер" — the cold map is
        keyed by short ID per channels.yaml.
        """
        if channel_id in self._is_cold:
            return self._is_cold[channel_id]
        short_id = channel_id.split(" ", 1)[0] if " " in channel_id else channel_id
        return self._is_cold.get(short_id, True)

    def push(self, channel_id: str, timestamp: float, value: float) -> None:
        """Add a data point for a channel.

        Phase 2c user report: only physical sensor channels are buffered.
        Derived / system / analytics channels are silently dropped — they
        don't have noise/drift physics so health scoring is meaningless,
        and including them produces a wall of red zeroes in the panel.
        """
        if not is_physical_sensor(channel_id):
            return
        buf = self._buffers.setdefault(channel_id, deque(maxlen=self._maxlen))
        buf.append((timestamp, value))

    def update(self) -> list:
        """Recompute diagnostics for all channels with data.

        Returns list of newly published AlarmEvent objects so the engine's
        sensor_diag_tick can dispatch Telegram notifications (F10 Cycle 3).
        Empty list when alarm_publisher is None or no new events triggered.
        """
        now = datetime.now(UTC)
        for channel_id, buf in self._buffers.items():
            if not buf:
                # Remove stale cached result so _update_anomaly_tracking
                # correctly classifies this channel as no_data.
                self._diagnostics.pop(channel_id, None)
                continue
            diag = self._compute_channel(channel_id, buf, now)
            self._diagnostics[channel_id] = diag
        if self._alarm_publisher is not None:
            return self._update_anomaly_tracking()
        return []

    def _update_anomaly_tracking(self) -> list:
        """Update per-channel anomaly duration and publish alarms when sustained.

        Returns list of newly published AlarmEvent objects (non-None returns from
        publish_diagnostic_alarm) so callers can dispatch notifications.
        """
        # v0.55.5 — during the cold-start grace window we suppress alarm
        # publishing entirely. We still skip the per-channel state machine
        # so anomaly accumulation does not start counting against the
        # warning/critical thresholds while sensors are still seeding.
        if self._is_in_grace_period():
            return []
        now_mono = time.monotonic()
        current_channels = set(self._diagnostics.keys())
        new_events: list = []

        for channel_id, diag in self._diagnostics.items():
            status = _health_to_status(diag.health_score)

            if status == "ok":
                if channel_id in self._anomaly_state:
                    state = self._anomaly_state.pop(channel_id)
                    if (
                        state.last_warning_published_ts is not None
                        or state.last_critical_published_ts is not None
                    ):
                        self._alarm_publisher.clear_diagnostic_alarm(channel_id)
            else:
                if channel_id not in self._anomaly_state:
                    self._anomaly_state[channel_id] = _AnomalyState(
                        channel_id=channel_id,
                        first_anomaly_ts=now_mono,
                        current_status=status,
                    )
                state = self._anomaly_state[channel_id]
                state.current_status = status
                elapsed = now_mono - state.first_anomaly_ts

                if elapsed >= self._warning_duration_s and state.last_warning_published_ts is None:
                    event = self._alarm_publisher.publish_diagnostic_alarm(
                        channel_id, "warning", elapsed
                    )
                    state.last_warning_published_ts = now_mono
                    if event is not None:
                        # F20 cooldown: suppress re-notification if channel was recently notified.
                        # Only applies when channel has a prior notification record — first
                        # notification is never suppressed.
                        within_cooldown = (
                            self._escalation_cooldown_s > 0
                            and channel_id in self._channel_last_notified
                            and now_mono - self._channel_last_notified[channel_id]
                            < self._escalation_cooldown_s
                        )
                        if not within_cooldown:
                            self._channel_last_notified[channel_id] = now_mono
                            new_events.append(event)

                if (
                    elapsed >= self._critical_duration_s
                    and state.current_status == "critical"
                    and state.last_critical_published_ts is None
                ):
                    event = self._alarm_publisher.publish_diagnostic_alarm(
                        channel_id, "critical", elapsed
                    )
                    state.last_critical_published_ts = now_mono
                    if event is not None:
                        # Critical escalation always notifies — cooldown never suppresses
                        # critical. Cooldown is designed to prevent warning re-triggers,
                        # not severity upgrades.
                        self._channel_last_notified[channel_id] = now_mono
                        new_events.append(event)

        # Channels in anomaly state but no longer in diagnostics: no_data — keep alarm, log
        for channel_id in list(self._anomaly_state.keys()):
            if channel_id not in current_channels:
                logger.debug("Diagnostic anomaly for %s: no_data, keeping alarm active", channel_id)

        return new_events

    def get_diagnostics(self) -> dict[str, ChannelDiagnostics]:
        """All channel diagnostics."""
        return dict(self._diagnostics)

    def get_summary(self) -> DiagnosticsSummary:
        """Aggregate summary for status bar."""
        diags = list(self._diagnostics.values())
        if not diags:
            return DiagnosticsSummary(
                total_channels=0,
                healthy=0,
                warning=0,
                critical=0,
                worst_channel="",
                worst_score=100,
                worst_flags=[],
            )
        # v0.55.2 A4: warm reference channels carry health_score=-1
        # ("not scored"). Exclude them from the healthy/warning/critical
        # buckets and from the worst-of search so they don't drag the
        # summary into a spurious red.
        scored = [d for d in diags if d.health_score >= 0]
        healthy = sum(1 for d in scored if d.health_score >= 80)
        warning = sum(1 for d in scored if 50 <= d.health_score < 80)
        critical = sum(1 for d in scored if d.health_score < 50)
        worst = min(scored, key=lambda d: d.health_score) if scored else diags[0]
        return DiagnosticsSummary(
            total_channels=len(diags),
            healthy=healthy,
            warning=warning,
            critical=critical,
            worst_channel=worst.channel_id,
            worst_score=worst.health_score,
            worst_flags=list(worst.fault_flags),
        )

    # -------------------------------------------------------------------
    # Internal computation
    # -------------------------------------------------------------------

    def _compute_channel(
        self,
        channel_id: str,
        buf: deque[tuple[float, float]],
        now: datetime,
    ) -> ChannelDiagnostics:
        current_T = buf[-1][1]
        name = self._channel_names.get(channel_id, channel_id)

        # v0.55.2 A4: warm reference channels sit at room temperature and
        # never satisfy the cryogenic noise/drift thresholds. Return a
        # neutral "not scored" diagnostic with health_score=-1 so the
        # GUI renders a dash instead of КРИТ.
        if not self._is_channel_cold(channel_id):
            return ChannelDiagnostics(
                channel_id=channel_id,
                channel_name=name,
                current_T=current_T,
                noise_std=float("nan"),
                noise_mK=float("nan"),
                drift_rate=float("nan"),
                drift_mK_per_min=float("nan"),
                outlier_count=0,
                correlation=None,
                health_score=-1,
                fault_flags=["warm_reference"],
                updated_at=now,
            )

        # Noise (over noise window)
        noise_points = self._window_values(buf, self.noise_window_s)
        if len(noise_points) >= self.min_points:
            noise_std = _mad_sigma(noise_points)
        else:
            noise_std = float("nan")

        # Drift (over drift window)
        drift_points = self._window_points(buf, self.drift_window_s)
        if len(drift_points) >= self.min_points:
            drift_rate = _ols_slope_per_min(drift_points)
            if drift_rate is None:
                drift_rate = float("nan")
        else:
            drift_rate = float("nan")

        # Outliers (over outlier window)
        outlier_points = self._window_values(buf, self.outlier_window_s)
        outlier_count = self._count_outliers(outlier_points)

        # Correlation
        correlation = self._compute_correlation(channel_id)

        # Fault flags
        fault_flags = self._compute_fault_flags(
            current_T,
            noise_std,
            drift_rate,
            outlier_count,
            correlation,
        )

        # Health score
        health_score = self._compute_health(
            noise_std,
            drift_rate,
            outlier_count,
            correlation,
            current_T,
        )

        return ChannelDiagnostics(
            channel_id=channel_id,
            channel_name=name,
            current_T=current_T,
            noise_std=noise_std if math.isfinite(noise_std) else float("nan"),
            noise_mK=noise_std * 1000.0 if math.isfinite(noise_std) else float("nan"),
            drift_rate=drift_rate if math.isfinite(drift_rate) else float("nan"),
            drift_mK_per_min=drift_rate * 1000.0 if math.isfinite(drift_rate) else float("nan"),
            outlier_count=outlier_count,
            correlation=correlation,
            health_score=health_score,
            fault_flags=fault_flags,
            updated_at=now,
        )

    def _window_values(self, buf: deque[tuple[float, float]], window_s: float) -> np.ndarray:
        """Extract values within the last window_s seconds."""
        if not buf:
            return np.array([])
        latest_ts = buf[-1][0]
        cutoff = latest_ts - window_s
        return np.array([v for t, v in buf if t >= cutoff])

    def _window_points(
        self, buf: deque[tuple[float, float]], window_s: float
    ) -> list[tuple[float, float]]:
        """Extract (ts, value) pairs within the last window_s seconds."""
        if not buf:
            return []
        latest_ts = buf[-1][0]
        cutoff = latest_ts - window_s
        return [(t, v) for t, v in buf if t >= cutoff]

    def _count_outliers(self, values: np.ndarray) -> int:
        """Count values deviating > outlier_sigma × MAD-σ from median."""
        if len(values) < self.min_points:
            return 0
        median = np.median(values)
        sigma = _mad_sigma(values)
        if sigma == 0.0 or not math.isfinite(sigma):
            return 0
        return int(np.sum(np.abs(values - median) > self.outlier_sigma * sigma))

    def _resolve_channel(self, short_id: str) -> str:
        """Resolve short config ID ('Т12') to full runtime name ('Т12 Теплообменник 2').

        Config uses short IDs, runtime uses full names from drivers.
        """
        if short_id in self._buffers:
            return short_id
        for full_id in self._buffers:
            if full_id.split(" ", 1)[0] == short_id:
                return full_id
        return short_id

    def _compute_correlation(self, channel_id: str) -> float | None:
        """Pearson r with best-correlated neighbour in the same group."""
        # Resolve full channel_id → short ID for group lookup
        short_id = channel_id.split(" ", 1)[0] if " " in channel_id else channel_id
        group_name = self._channel_to_group.get(short_id)
        if group_name is None:
            group_name = self._channel_to_group.get(channel_id)
        if group_name is None:
            return None
        group_channels = self._correlation_groups.get(group_name, [])
        # Resolve short config IDs to full runtime names, exclude self
        neighbours = []
        for ch in group_channels:
            full = self._resolve_channel(ch)
            if full != channel_id and full in self._buffers:
                neighbours.append(full)
        if not neighbours:
            return None

        my_buf = self._buffers[channel_id]
        my_points = self._window_points(my_buf, self.corr_window_s)
        if len(my_points) < self.min_points:
            return None

        # Build aligned arrays by matching timestamps.
        # Round to millisecond precision to handle float imprecision
        # (two readings "at the same time" may differ by ~1e-9).
        _TS_ROUND = 3  # decimal places = milliseconds
        my_ts_map = {round(t, _TS_ROUND): v for t, v in my_points}
        best_r: float | None = None
        for neighbour_id in neighbours:
            n_buf = self._buffers[neighbour_id]
            n_points = self._window_points(n_buf, self.corr_window_s)
            if len(n_points) < self.min_points:
                continue

            # Align by common rounded timestamps
            n_map = {round(t, _TS_ROUND): v for t, v in n_points}
            common_ts = sorted(set(my_ts_map.keys()) & set(n_map.keys()))
            if len(common_ts) < self.min_points:
                continue

            my_vals = np.array([my_ts_map[t] for t in common_ts])
            n_vals = np.array([n_map[t] for t in common_ts])

            r = _pearson_r(my_vals, n_vals)
            if r is not None and (best_r is None or r > best_r):
                best_r = r

        return best_r

    def _compute_fault_flags(
        self,
        current_T: float,
        noise_std: float,
        drift_rate: float,
        outlier_count: int,
        correlation: float | None,
    ) -> list[str]:
        flags: list[str] = []
        if current_T > 350.0:
            flags.append("disconnected")
        if current_T <= 0.0:
            flags.append("shorted")
        if math.isfinite(noise_std):
            threshold = _get_noise_threshold(current_T)
            if noise_std > threshold:
                flags.append("noisy")
        if math.isfinite(drift_rate) and abs(drift_rate) > self.drift_threshold:
            flags.append("drifting")
        if correlation is not None and correlation < self.corr_min:
            flags.append("uncorrelated")
        return flags

    def _compute_health(
        self,
        noise: float,
        drift: float,
        outliers: int,
        correlation: float | None,
        T_current: float,
    ) -> int:
        # NaN current reading → cannot be scored healthy (D-C19). NaN-доктрина:
        # validity is decided at the Reading boundary (engine _sensor_diag_feed
        # gates on reading.is_usable()). push() here is a status-less float API,
        # so this stays as fail-closed defense-in-depth for any direct/GUI caller
        # that bypasses the boundary: a NaN slips through the disconnected(>350)/
        # shorted(<=0) comparisons (all comparisons with NaN are False) and would
        # otherwise reach the insufficient-data branch below and return 100.
        if not math.isfinite(T_current):
            return 0

        # Disconnected / shorted → immediate low score
        if T_current > 350.0 or T_current <= 0.0:
            return 0

        # Insufficient data → no penalty
        if not math.isfinite(noise) and not math.isfinite(drift):
            return 100

        health = 100

        # Noise penalty (temperature-dependent thresholds)
        if math.isfinite(noise):
            threshold = _get_noise_threshold(T_current)
            if noise > threshold * 3:
                health -= 40
            elif noise > threshold:
                health -= 20

        # Drift penalty
        if math.isfinite(drift) and abs(drift) > self.drift_threshold:
            health -= 25

        # Outlier penalty
        if outliers > 5:
            health -= 30
        elif outliers > 2:
            health -= 15

        # Correlation penalty
        if correlation is not None and correlation < self.corr_min:
            health -= 20

        return max(0, health)
