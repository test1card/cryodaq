"""AlarmPanel — Phase II.4 dual-engine alarm overlay (K1-critical).

Supersedes ``src/cryodaq/gui/widgets/alarm_panel.py``. Preserves both
alarm engines:

- **v1 (threshold-based):** rows fed via ``on_reading(reading)`` filter
  on ``metadata["alarm_name"]``. Engine is the legacy ``AlarmEngine``.
- **v2 (YAML-driven, phase-aware):** table populated via 3 s polling
  of ``alarm_v2_status``. Engine is ``AlarmEngine v2``.

Replaces legacy emoji severity icons with an in-module
``SeverityChip`` widget using DS status tokens. Preserves the
``v2_alarm_count_changed = Signal(int)`` signature — consumed by the
launcher tray icon via ``MainWindowV2._top_bar.set_alarm_count``.

K1-critical: operator uses this overlay to acknowledge safety alarms.
Fail-OPEN: disconnect keeps rows visible (stale data is better than
hidden alarms); engine errors keep last-known state (no table wipe).

Public API (host push points):
- ``on_reading(reading)`` — v1 reading sink; filters by
  ``metadata["alarm_name"]``.
- ``set_connected(bool)`` — gates acknowledge buttons; pauses v2 polling.
- ``update_v2_status(payload)`` — public path for host or tests.
- ``get_active_v1_count() / get_active_v2_count()`` — accessors for
  future finalize guards.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass

from PySide6.QtCore import Qt, QTimer, Signal, Slot
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from cryodaq.drivers.base import Reading
from cryodaq.gui import theme
from cryodaq.gui.shell.overlays._base_panel import OverlayPanelBase
from cryodaq.gui.utils.plural import ru_plural
from cryodaq.gui.zmq_client import ZmqCommandWorker

logger = logging.getLogger(__name__)

_V2_POLL_INTERVAL_MS = 3000

# Severity → DS status token. Safety semantics: hex values come from
# the STATUS_* tokens, not hardcoded. CRITICAL→FAULT (red), WARNING→
# WARNING (amber), INFO→INFO (blue).
_SEVERITY_TOKENS: dict[str, str] = {
    "CRITICAL": theme.STATUS_FAULT,
    "WARNING": theme.STATUS_WARNING,
    "INFO": theme.STATUS_INFO,
}

# Russian short labels for the severity chip. No emoji (RULE-COPY-005).
_SEVERITY_LABELS: dict[str, str] = {
    "CRITICAL": "КРИТ",
    "WARNING": "ПРЕД",
    "INFO": "ИНФО",
}

_SEVERITY_ORDER: dict[str, int] = {
    "CRITICAL": 0,
    "WARNING": 1,
    "INFO": 2,
}

_EVENT_TO_STATE: dict[str, str] = {
    "activated": "active",
    "acknowledged": "acknowledged",
    "cleared": "cleared",
}

_V1_COLUMNS: tuple[str, ...] = (
    "Уровень",
    "Имя",
    "Канал",
    "Значение",
    "Порог",
    "Время",
    "Срабат.",
    "Действие",
)

_V2_COLUMNS: tuple[str, ...] = (
    "Уровень",
    "Идентификатор",
    "Сообщение",
    "Каналы",
    "Время",
    "Действие",
)

_V2_MESSAGE_MAX_CHARS = 80


def _label_font() -> QFont:
    font = QFont(theme.FONT_BODY)
    font.setPixelSize(theme.FONT_LABEL_SIZE)
    font.setWeight(QFont.Weight(theme.FONT_LABEL_WEIGHT))
    return font


def _body_font() -> QFont:
    font = QFont(theme.FONT_BODY)
    font.setPixelSize(theme.FONT_BODY_SIZE)
    return font


def _title_font() -> QFont:
    font = QFont(theme.FONT_BODY)
    font.setPixelSize(theme.FONT_SIZE_XL)
    font.setWeight(QFont.Weight(theme.FONT_WEIGHT_SEMIBOLD))
    return font


def _section_title_font() -> QFont:
    font = QFont(theme.FONT_BODY)
    font.setPixelSize(theme.FONT_SIZE_LG)
    font.setWeight(QFont.Weight(theme.FONT_WEIGHT_SEMIBOLD))
    return font


def _mono_cell_font() -> QFont:
    font = QFont(theme.FONT_MONO)
    font.setPixelSize(theme.FONT_LABEL_SIZE)
    try:
        font.setFeature(QFont.Tag("tnum"), 1)
    except (AttributeError, TypeError):
        pass
    return font


def _chip_font() -> QFont:
    font = QFont(theme.FONT_MONO)
    font.setPixelSize(theme.FONT_SIZE_XS)
    font.setWeight(QFont.Weight(theme.FONT_WEIGHT_SEMIBOLD))
    return font


def _fmt_metric(x: float) -> str:
    """Format a value/threshold cell. A non-finite (NaN/Inf) reading — e.g. from
    a faulted sensor — renders as "—" rather than "nan" or a misleading "0", so
    the operator sees the value is unavailable, not a plausible measurement."""
    if not math.isfinite(x):
        return "—"
    return f"{x:.4g}"


def _elapsed_text(elapsed_s: float, *, unit: str = "с") -> str:
    """Format elapsed time with Russian buckets (s / мин / ч)."""
    if elapsed_s < 60:
        return f"{elapsed_s:.0f} {unit}"
    if elapsed_s < 3600:
        return f"{elapsed_s / 60:.0f} мин"
    return f"{elapsed_s / 3600:.1f} ч"


class SeverityChip(QLabel):
    """Small pill-shaped severity indicator using DS status tokens.

    Replaces the legacy emoji icons per RULE-COPY-005. Color comes
    from STATUS_FAULT / STATUS_WARNING / STATUS_INFO; text is a short
    Russian uppercase label in MONO font. Reused by both v1 and v2
    tables.
    """

    def __init__(
        self,
        severity: str,
        parent: QWidget | None = None,
        *,
        acknowledged: bool = False,
    ) -> None:
        super().__init__(parent)
        self._severity = severity.upper()
        self._acknowledged = bool(acknowledged)
        base_label = _SEVERITY_LABELS.get(self._severity, self._severity[:4])
        if self._acknowledged:
            label = f"✓ {base_label}"
            bg_color = theme.SURFACE_MUTED
            fg_color = theme.MUTED_FOREGROUND
        else:
            label = base_label
            bg_color = _SEVERITY_TOKENS.get(self._severity, theme.STATUS_INFO)
            fg_color = theme.ON_PRIMARY
        self.setText(label)
        self.setFont(_chip_font())
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(
            f"QLabel {{"
            f" background-color: {bg_color};"
            f" color: {fg_color};"
            f" border: none;"
            f" border-radius: {theme.RADIUS_SM}px;"
            f" padding: {theme.SPACE_0}px {theme.SPACE_2}px;"
            f" font-weight: {theme.FONT_WEIGHT_SEMIBOLD};"
            f"}}"
        )

    @property
    def severity(self) -> str:
        return self._severity


def _make_ack_button(severity: str, label: str = "ПОДТВЕРДИТЬ") -> QPushButton:
    """Build an acknowledge button colored by severity. No hardcoded hex —
    the color comes from the DS status token for the severity.
    """
    btn = QPushButton(label)
    color = _SEVERITY_TOKENS.get(severity.upper(), theme.STATUS_FAULT)
    btn.setFont(_chip_font())
    btn.setStyleSheet(
        f"QPushButton {{"
        f" background-color: {color};"
        f" color: {theme.ON_PRIMARY};"
        f" border: none;"
        f" border-radius: {theme.RADIUS_SM}px;"
        f" padding: {theme.SPACE_1}px {theme.SPACE_3}px;"
        f" font-weight: {theme.FONT_WEIGHT_SEMIBOLD};"
        f"}}"
        f" QPushButton:disabled {{"
        f" background-color: {theme.SURFACE_MUTED};"
        f" color: {theme.MUTED_FOREGROUND};"
        f"}}"
    )
    return btn


@dataclass
class _AlarmRow:
    """Internal row state for v1 alarms."""

    severity: str
    name: str
    channel: str
    value: float
    threshold: float
    first_triggered: float
    trigger_count: int
    state: str  # "ok" | "active" | "acknowledged" | "cleared"


def _card_qss(object_name: str) -> str:
    return (
        f"#{object_name} {{"
        f" background-color: {theme.SURFACE_CARD};"
        f" border: 1px solid {theme.BORDER_SUBTLE};"
        f" border-radius: {theme.RADIUS_MD}px;"
        f"}}"
    )


class AlarmPanel(OverlayPanelBase, QWidget):
    """Dual-engine alarm overlay (Phase II.4, K1-critical)."""

    _reading_signal = Signal(object)
    v2_alarm_count_changed = Signal(int)  # preserved for tray-icon consumer

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)  # OverlayPanelBase: _connected, _workers

        self._alarms: dict[str, _AlarmRow] = {}
        self._v2_alarms: dict[str, dict] = {}
        self._v2_poll_in_flight: bool = False
        self._v1_ack_buttons: list[QPushButton] = []
        self._v2_ack_buttons: list[QPushButton] = []
        self._read_only: bool = False

        self.setObjectName("alarmPanel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(f"#alarmPanel {{ background-color: {theme.BACKGROUND}; }}")

        # Cooldown control widget refs (set in _build_cooldown_control).
        # v0.55.6.1 — manual arm/disarm button removed; the alarm
        # auto-arms on phase=cooldown and auto-disarms on cooled state.
        # Status remains operator-visible (label + ETA + progress).
        self._cooldown_status_lbl: QLabel | None = None
        self._cooldown_eta_lbl: QLabel | None = None
        self._cooldown_progress: QProgressBar | None = None
        self._cooldown_poll_in_flight: bool = False

        self._build_ui()
        self._reading_signal.connect(self._handle_reading)

        self._v2_poll_timer = QTimer(self)
        self._v2_poll_timer.setInterval(_V2_POLL_INTERVAL_MS)
        self._v2_poll_timer.timeout.connect(self._poll_v2_status)
        # Polling starts only when shell pushes set_connected(True).

        self._cooldown_poll_timer = QTimer(self)
        self._cooldown_poll_timer.setInterval(5000)
        self._cooldown_poll_timer.timeout.connect(self._poll_cooldown_status)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(theme.SPACE_4, theme.SPACE_3, theme.SPACE_4, theme.SPACE_3)
        root.setSpacing(theme.SPACE_3)

        root.addWidget(self._build_header())

        # IV.3 F2: body is a QStackedWidget. Page 0 is the unified
        # "both lists empty" message — a single centered line rather
        # than two cards rendering their own empty tables side-by-side.
        # Page 1 is the existing two-card layout, preserved verbatim.
        self._body_stack = QStackedWidget()

        self._body_empty_page = self._build_unified_empty_page()
        self._body_stack.addWidget(self._body_empty_page)

        cards_page = QWidget()
        cards_layout = QVBoxLayout(cards_page)
        cards_layout.setContentsMargins(0, 0, 0, 0)
        cards_layout.setSpacing(theme.SPACE_3)
        cards_layout.addWidget(self._build_v1_card())
        cards_layout.addWidget(self._build_v2_card(), stretch=1)
        self._body_stack.addWidget(cards_page)

        self._body_stack.setCurrentWidget(self._body_empty_page)
        root.addWidget(self._body_stack, stretch=1)
        root.addWidget(self._build_cooldown_control())

    def _build_cooldown_control(self) -> QGroupBox:
        """Status footer for CooldownAlarm.

        v0.55.6.1 — read-only: the alarm auto-arms when the experiment
        enters phase=cooldown (architect 2026-05-07: «он же должен
        всегда работать, если это аларм»). The arm/disarm button used
        to clutter this footer with a redundant manual control; status
        + ETA + progress now telegraph the same information without
        asking the operator to do anything.
        """
        group = QGroupBox("Контроль захолаживания")
        group.setObjectName("cooldownControl")
        layout = QVBoxLayout(group)
        layout.setContentsMargins(theme.SPACE_3, theme.SPACE_2, theme.SPACE_3, theme.SPACE_2)
        layout.setSpacing(theme.SPACE_2)

        # Row 1: status (full-width — no button competing for space).
        row1 = QHBoxLayout()
        self._cooldown_status_lbl = QLabel("Ожидает фазы захолаживания")
        self._cooldown_status_lbl.setStyleSheet(f"color: {theme.MUTED_FOREGROUND};")
        self._cooldown_status_lbl.setToolTip(
            "Контроль включается автоматически при переходе в фазу "
            "«Захолаживание» и выключается при достижении базовой "
            "температуры."
        )
        row1.addWidget(self._cooldown_status_lbl, stretch=1)
        layout.addLayout(row1)

        # Row 2: ETA + progress (hidden until WATCHING+).
        row2 = QHBoxLayout()
        self._cooldown_eta_lbl = QLabel("")
        self._cooldown_eta_lbl.setVisible(False)
        row2.addWidget(self._cooldown_eta_lbl, stretch=1)

        self._cooldown_progress = QProgressBar()
        self._cooldown_progress.setRange(0, 100)
        self._cooldown_progress.setVisible(False)
        self._cooldown_progress.setMaximumHeight(12)
        row2.addWidget(self._cooldown_progress)
        layout.addLayout(row2)

        return group

    def _build_unified_empty_page(self) -> QWidget:
        """Full-overlay centered empty state when both alarm lists are empty."""
        page = QWidget()
        page.setObjectName("alarmUnifiedEmpty")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(theme.SPACE_5, theme.SPACE_5, theme.SPACE_5, theme.SPACE_5)
        layout.setSpacing(theme.SPACE_2)
        layout.addStretch(1)

        title = QLabel("Нет активных тревог.")
        title.setFont(_section_title_font())
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # IV.3 F2 amend: unified empty-state title uses MUTED_FOREGROUND
        # per the DS empty-state convention — a full-weight FOREGROUND
        # here competes visually with the actual alarm rows.
        title.setStyleSheet(f"color: {theme.MUTED_FOREGROUND}; background: transparent; border: none;")
        layout.addWidget(title)

        subtitle = QLabel("Система отслеживает все каналы автоматически.")
        subtitle.setFont(_body_font())
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet(
            f"color: {theme.MUTED_FOREGROUND}; background: transparent; border: none; font-style: italic;"
        )
        layout.addWidget(subtitle)

        layout.addStretch(1)
        return page

    def _build_header(self) -> QWidget:
        header = QWidget()
        layout = QHBoxLayout(header)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(theme.SPACE_2)
        title = QLabel("ТРЕВОГИ")
        title.setFont(_title_font())
        title.setStyleSheet(f"color: {theme.FOREGROUND}; background: transparent; border: none; letter-spacing: 1px;")
        layout.addWidget(title)
        layout.addStretch()
        self._summary_label = QLabel("")
        self._summary_label.setFont(_label_font())
        self._summary_label.setStyleSheet(f"color: {theme.MUTED_FOREGROUND}; background: transparent; border: none;")
        self._summary_label.setVisible(False)
        layout.addWidget(self._summary_label)
        return header

    def _build_v1_card(self) -> QWidget:
        card = QFrame()
        card.setObjectName("alarmV1Card")
        card.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        card.setStyleSheet(_card_qss("alarmV1Card"))
        layout = QVBoxLayout(card)
        layout.setContentsMargins(theme.SPACE_3, theme.SPACE_3, theme.SPACE_3, theme.SPACE_3)
        layout.setSpacing(theme.SPACE_2)

        title = QLabel("Пороговые тревоги")
        title.setFont(_section_title_font())
        title.setStyleSheet(f"color: {theme.FOREGROUND}; background: transparent; border: none;")
        layout.addWidget(title)

        self._table = QTableWidget(0, len(_V1_COLUMNS))
        self._table.setHorizontalHeaderLabels(list(_V1_COLUMNS))
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(False)
        self._table.verticalHeader().setVisible(False)
        self._table.setFont(_body_font())
        self._style_table(self._table)
        header_v = self._table.horizontalHeader()
        header_v.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        header_v.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header_v.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        header_v.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self._table)

        # IV.3 F2: inline per-card empty hint. Rendered only when the
        # body stack is on page 1 (i.e. the OTHER card has data); the
        # unified empty page handles the both-empty state.
        self._v1_empty_label = QLabel("Нет пороговых тревог")
        self._v1_empty_label.setFont(_body_font())
        self._v1_empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._v1_empty_label.setStyleSheet(
            f"color: {theme.MUTED_FOREGROUND};"
            f" background: transparent; border: none;"
            f" padding: {theme.SPACE_2}px;"
            f" font-style: italic;"
        )
        self._v1_empty_label.setVisible(False)
        layout.addWidget(self._v1_empty_label)

        return card

    def _build_v2_card(self) -> QWidget:
        card = QFrame()
        card.setObjectName("alarmV2Card")
        card.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        card.setStyleSheet(_card_qss("alarmV2Card"))
        layout = QVBoxLayout(card)
        layout.setContentsMargins(theme.SPACE_3, theme.SPACE_3, theme.SPACE_3, theme.SPACE_3)
        layout.setSpacing(theme.SPACE_2)

        title = QLabel("Фазо-зависимые тревоги")
        title.setFont(_section_title_font())
        title.setStyleSheet(f"color: {theme.FOREGROUND}; background: transparent; border: none;")
        layout.addWidget(title)

        self._v2_table = QTableWidget(0, len(_V2_COLUMNS))
        self._v2_table.setHorizontalHeaderLabels(list(_V2_COLUMNS))
        self._v2_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._v2_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._v2_table.setAlternatingRowColors(False)
        self._v2_table.verticalHeader().setVisible(False)
        self._v2_table.setMaximumHeight(240)
        self._v2_table.setFont(_body_font())
        self._style_table(self._v2_table)
        header_v2 = self._v2_table.horizontalHeader()
        header_v2.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        header_v2.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header_v2.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self._v2_table)

        # IV.3 F2: inline per-card empty hint. Rendered only when the
        # body stack is on page 1 (i.e. v1 has data but v2 doesn't);
        # the unified empty page owns the both-empty case. This label
        # replaces the old "Нет активных алармов. Система отслеживает
        # все каналы автоматически." text which is now carried by the
        # unified empty page.
        self._v2_empty_label = QLabel("Нет фазо-зависимых тревог")
        self._v2_empty_label.setFont(_body_font())
        self._v2_empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._v2_empty_label.setStyleSheet(
            f"color: {theme.MUTED_FOREGROUND};"
            f" background: transparent; border: none;"
            f" padding: {theme.SPACE_2}px;"
            f" font-style: italic;"
        )
        self._v2_empty_label.setVisible(False)
        layout.addWidget(self._v2_empty_label)

        return card

    @staticmethod
    def _style_table(table: QTableWidget) -> None:
        table.setStyleSheet(
            f"QTableWidget {{"
            f" background-color: {theme.SURFACE_CARD};"
            f" color: {theme.FOREGROUND};"
            f" gridline-color: {theme.BORDER_SUBTLE};"
            f" border: 1px solid {theme.BORDER_SUBTLE};"
            f" border-radius: {theme.RADIUS_SM}px;"
            f"}} "
            f"QHeaderView::section {{"
            f" background-color: {theme.SURFACE_MUTED};"
            f" color: {theme.MUTED_FOREGROUND};"
            f" border: 0px;"
            f" border-bottom: 1px solid {theme.BORDER_SUBTLE};"
            f" padding: {theme.SPACE_1}px {theme.SPACE_2}px;"
            f"}}"
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def on_reading(self, reading: Reading) -> None:
        """Thread-safe entry — marshals the reading to the GUI thread."""
        self._reading_signal.emit(reading)

    def set_connected(self, connected: bool) -> None:
        if not super().set_connected(connected):
            return
        if self._connected:
            if not self._v2_poll_timer.isActive():
                self._v2_poll_timer.start()
            if not self._cooldown_poll_timer.isActive():
                self._cooldown_poll_timer.start()
        else:
            self._v2_poll_timer.stop()
            self._cooldown_poll_timer.stop()
        self._apply_ack_enabled()

    def set_read_only(self, read_only: bool) -> None:
        """Preserve alarm inspection while disabling replay acknowledgement."""

        self._read_only = bool(read_only)
        self._apply_ack_enabled()

    def update_v2_status(self, payload: dict) -> None:
        """Update v2 alarm table from an ``alarm_v2_status`` payload.

        Public path — host or tests can call directly without going
        through the 3 s poll.
        """
        active = payload.get("active") or {}
        if not isinstance(active, dict):
            active = {}
        self._v2_alarms = dict(active)
        self._refresh_v2_table()
        self.v2_alarm_count_changed.emit(len(self._v2_alarms))
        self._refresh_summary()

    def get_active_v1_count(self) -> int:
        return sum(1 for row in self._alarms.values() if row.state == "active")

    def get_active_v2_count(self) -> int:
        return len(self._v2_alarms)

    # ------------------------------------------------------------------
    # v1 reading path
    # ------------------------------------------------------------------

    @Slot(object)
    def _handle_reading(self, reading: Reading) -> None:
        meta = reading.metadata or {}
        alarm_name = meta.get("alarm_name")
        if not alarm_name:
            return
        severity = str(meta.get("severity", "INFO")).upper()
        event_type = str(meta.get("event_type", ""))
        threshold_raw = meta.get("threshold", 0.0)
        try:
            threshold = float(threshold_raw)
        except (TypeError, ValueError):
            threshold = 0.0
        try:
            value = float(reading.value)
        except (TypeError, ValueError):
            value = 0.0
        channel_display = str(meta.get("channel", reading.channel))

        if alarm_name in self._alarms:
            row = self._alarms[alarm_name]
            row.value = value
            row.channel = channel_display
            row.severity = severity or row.severity
            if event_type == "activated":
                row.trigger_count += 1
            if event_type in _EVENT_TO_STATE:
                row.state = _EVENT_TO_STATE[event_type]
        else:
            self._alarms[alarm_name] = _AlarmRow(
                severity=severity,
                name=alarm_name,
                channel=channel_display,
                value=value,
                threshold=threshold,
                first_triggered=time.monotonic(),
                trigger_count=1 if event_type == "activated" else 0,
                state=_EVENT_TO_STATE.get(event_type, "ok"),
            )

        self._refresh_table()
        # IV.3 F2: body-stack state depends on both v1 and v2 counts;
        # v1 changes through _handle_reading must also trigger the swap.
        self._update_body_stack_state()
        self._refresh_summary()

    # ------------------------------------------------------------------
    # v1 table render
    # ------------------------------------------------------------------

    def _refresh_table(self) -> None:
        sorted_alarms = sorted(
            self._alarms.values(),
            key=lambda a: (_SEVERITY_ORDER.get(a.severity, 99), a.name),
        )
        self._table.setRowCount(len(sorted_alarms))
        self._v1_ack_buttons = []

        mono = _mono_cell_font()

        def _cell(text: str, *, mono_font: bool = False) -> QTableWidgetItem:
            item = QTableWidgetItem(text)
            if mono_font:
                item.setFont(mono)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            return item

        for row_idx, alarm in enumerate(sorted_alarms):
            # v0.55.4 A1 fix: v0.55.2 only patched the v2 path; the v1
            # threshold-based table also has acknowledged state on
            # `alarm.state == "acknowledged"`, so propagate the flag to
            # SeverityChip and mute the data columns the same way.
            acknowledged = alarm.state == "acknowledged"
            chip = SeverityChip(alarm.severity, acknowledged=acknowledged)
            self._table.setCellWidget(row_idx, 0, chip)
            self._table.setItem(row_idx, 1, _cell(alarm.name))
            self._table.setItem(row_idx, 2, _cell(alarm.channel))
            self._table.setItem(row_idx, 3, _cell(_fmt_metric(alarm.value), mono_font=True))
            self._table.setItem(row_idx, 4, _cell(_fmt_metric(alarm.threshold), mono_font=True))
            elapsed = time.monotonic() - alarm.first_triggered
            self._table.setItem(row_idx, 5, _cell(_elapsed_text(elapsed)))
            self._table.setItem(row_idx, 6, _cell(str(alarm.trigger_count), mono_font=True))
            if acknowledged:
                muted = QColor(theme.MUTED_FOREGROUND)
                for col in (1, 2, 3, 4, 5, 6):
                    item = self._table.item(row_idx, col)
                    if item is not None:
                        item.setForeground(muted)
            if alarm.state == "active":
                btn = _make_ack_button(alarm.severity)
                btn.clicked.connect(lambda _checked=False, name=alarm.name: self._acknowledge(name))
                btn.setEnabled(self._connected and not self._read_only)
                self._v1_ack_buttons.append(btn)
                self._table.setCellWidget(row_idx, 7, btn)
            else:
                state_label = {
                    "ok": "Норма",
                    "cleared": "Сброшена",
                    "acknowledged": "Подтв.",
                }.get(alarm.state, alarm.state)
                self._table.setItem(row_idx, 7, _cell(state_label))

    def _refresh_v2_table(self) -> None:
        def _sort_key(kv: tuple[str, dict]) -> tuple[int, str]:
            level = str(kv[1].get("level", "INFO")).upper()
            return (_SEVERITY_ORDER.get(level, 99), kv[0])

        sorted_items = sorted(self._v2_alarms.items(), key=_sort_key)
        self._v2_table.setRowCount(len(sorted_items))
        self._v2_ack_buttons = []

        mono = _mono_cell_font()

        def _cell(text: str, *, mono_font: bool = False) -> QTableWidgetItem:
            item = QTableWidgetItem(text)
            if mono_font:
                item.setFont(mono)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            return item

        for row_idx, (alarm_id, info) in enumerate(sorted_items):
            level = str(info.get("level", "INFO")).upper()
            message = str(info.get("message", ""))
            if len(message) > _V2_MESSAGE_MAX_CHARS:
                message = message[: _V2_MESSAGE_MAX_CHARS - 1] + "…"
            channels_raw = info.get("channels") or []
            channels_text = ", ".join(str(c) for c in channels_raw)
            triggered_at_raw = info.get("triggered_at", 0.0)
            try:
                triggered_at = float(triggered_at_raw)
            except (TypeError, ValueError):
                triggered_at = 0.0
            if triggered_at > 0:
                elapsed = time.time() - triggered_at
                time_text = _elapsed_text(max(0.0, elapsed))
            else:
                time_text = "—"
            acknowledged = bool(info.get("acknowledged", False))

            chip = SeverityChip(level, acknowledged=acknowledged)
            self._v2_table.setCellWidget(row_idx, 0, chip)
            self._v2_table.setItem(row_idx, 1, _cell(str(alarm_id), mono_font=True))
            self._v2_table.setItem(row_idx, 2, _cell(message))
            self._v2_table.setItem(row_idx, 3, _cell(channels_text))
            self._v2_table.setItem(row_idx, 4, _cell(time_text))
            # IV.2 A.2 (v0.55.2): mute non-chip cells when alarm is
            # acknowledged so operators visibly distinguish "still firing
            # but seen" from "fresh and demanding attention". The chip
            # itself is muted via SeverityChip(acknowledged=True) above.
            if acknowledged:
                muted = QColor(theme.MUTED_FOREGROUND)
                for col in (1, 2, 3, 4):
                    item = self._v2_table.item(row_idx, col)
                    if item is not None:
                        item.setForeground(muted)

            # IV.2 A.2: v2 rendering previously left the "ПОДТВЕРДИТЬ"
            # button in place even after the engine had recorded the
            # acknowledgement — operators perceived the action as having
            # no effect and clicked repeatedly. Mirror the v1 branch:
            # once engine reports acknowledged=True, replace the button
            # with a static label so it's clear the action landed.
            #
            # QTableWidget does not auto-evict a cellWidget when setItem
            # is called on the same cell, so the previous button would
            # persist visually across the unack → ack transition. Clear
            # it explicitly before each render.
            self._v2_table.removeCellWidget(row_idx, 5)
            self._v2_table.setItem(row_idx, 5, None)
            if acknowledged:
                operator = str(info.get("acknowledged_by") or "").strip()
                ack_text = "Подтв." if not operator else f"Подтв. ({operator})"
                ack_item = _cell(ack_text)
                ack_item.setForeground(QColor(theme.MUTED_FOREGROUND))
                self._v2_table.setItem(row_idx, 5, ack_item)
            else:
                btn = _make_ack_button(level, label="ПОДТВЕРДИТЬ")
                btn.clicked.connect(lambda _checked=False, aid=alarm_id: self._acknowledge_v2(aid))
                btn.setEnabled(self._connected and not self._read_only)
                self._v2_ack_buttons.append(btn)
                self._v2_table.setCellWidget(row_idx, 5, btn)

        # IV.3 F2: v2_empty_label visibility is now owned by
        # _update_body_stack_state; don't toggle it here.
        self._update_body_stack_state()

    def _update_body_stack_state(self) -> None:
        """Swap the body stack between unified empty and two-card layout.

        IV.3 F2: when both v1 and v2 are empty, show a single centered
        "Нет активных тревог." message across the overlay body. When
        at least one list has entries, show the two-card layout; the
        card whose table has zero rows gets its inline
        «Нет <...> тревог» hint so the operator can tell the empty
        card from a broken one.
        """
        v1_count = self.get_active_v1_count()
        v2_count = len(self._v2_alarms)
        both_empty = v1_count == 0 and v2_count == 0
        target_idx = 0 if both_empty else 1
        if self._body_stack.currentIndex() != target_idx:
            self._body_stack.setCurrentIndex(target_idx)
        # Inline per-card hint only when the OTHER card has data.
        self._v1_empty_label.setVisible(not both_empty and v1_count == 0)
        self._v2_empty_label.setVisible(not both_empty and v2_count == 0)

    def _refresh_summary(self) -> None:
        v1_active = self.get_active_v1_count()
        v2_counts: dict[str, int] = {"CRITICAL": 0, "WARNING": 0, "INFO": 0}
        for info in self._v2_alarms.values():
            level = str(info.get("level", "INFO")).upper()
            if level in v2_counts:
                v2_counts[level] += 1
        total_critical = (
            sum(1 for row in self._alarms.values() if row.state == "active" and row.severity == "CRITICAL")
            + v2_counts["CRITICAL"]
        )
        total_warning = (
            sum(1 for row in self._alarms.values() if row.state == "active" and row.severity == "WARNING")
            + v2_counts["WARNING"]
        )

        if total_critical == 0 and total_warning == 0 and v1_active == 0:
            self._summary_label.setText("")
            self._summary_label.setVisible(False)
            return

        parts: list[str] = []
        if total_critical:
            word = ru_plural(total_critical, "критический", "критических", "критических")
            parts.append(f"{total_critical} {word}")
        if total_warning:
            word = ru_plural(total_warning, "предупреждение", "предупреждения", "предупреждений")
            parts.append(f"{total_warning} {word}")
        self._summary_label.setText(", ".join(parts))
        self._summary_label.setVisible(True)

    # ------------------------------------------------------------------
    # Acknowledge dispatch
    # ------------------------------------------------------------------

    def _acknowledge(self, alarm_name: str) -> None:
        if self._read_only:
            return
        worker = ZmqCommandWorker({"cmd": "alarm_acknowledge", "alarm_name": alarm_name}, parent=self)
        self._register_worker(worker, lambda result, name=alarm_name: self._on_ack_result(result, name))

    def _on_ack_result(self, result: dict, alarm_name: str) -> None:
        if result.get("ok"):
            logger.info("Alarm '%s' acknowledged via engine", alarm_name)
        else:
            logger.warning(
                "Alarm '%s' acknowledge failed: %s",
                alarm_name,
                result.get("error"),
            )

    def _acknowledge_v2(self, alarm_id: str) -> None:
        if self._read_only:
            return
        worker = ZmqCommandWorker({"cmd": "alarm_v2_ack", "alarm_name": alarm_id}, parent=self)
        self._register_worker(worker, lambda result, aid=alarm_id: self._on_ack_v2_result(result, aid))

    def _on_ack_v2_result(self, result: dict, alarm_id: str) -> None:
        if result.get("ok"):
            logger.info("Alarm v2 '%s' acknowledged", alarm_id)
        else:
            logger.warning(
                "Alarm v2 '%s' acknowledge failed: %s",
                alarm_id,
                result.get("error"),
            )

    # ------------------------------------------------------------------
    # v2 polling
    # ------------------------------------------------------------------

    @Slot()
    def _poll_v2_status(self) -> None:
        if not self._connected:
            return
        if self._v2_poll_in_flight:
            return
        self._v2_poll_in_flight = True
        worker = ZmqCommandWorker({"cmd": "alarm_v2_status"}, parent=self)
        self._register_worker(worker, self._on_poll_v2_result)

    def _on_poll_v2_result(self, result: dict) -> None:
        self._v2_poll_in_flight = False
        if not isinstance(result, dict):
            return
        if result.get("ok"):
            self.update_v2_status(result)

    # ------------------------------------------------------------------
    # Cooldown alarm control
    # ------------------------------------------------------------------

    @Slot()
    def _poll_cooldown_status(self) -> None:
        if not self._connected or self._cooldown_poll_in_flight:
            return
        self._cooldown_poll_in_flight = True
        worker = ZmqCommandWorker({"cmd": "cooldown_alarm.status"}, parent=self)
        self._register_worker(worker, self._on_cooldown_status)

    def _on_cooldown_status(self, result: dict) -> None:
        self._cooldown_poll_in_flight = False
        if not isinstance(result, dict):
            return
        state = result.get("state", "UNAVAILABLE")
        progress = result.get("progress")
        eta_h = result.get("eta_h")
        t_cold = result.get("t_cold")
        self._update_cooldown_ui(state, progress, eta_h, t_cold=t_cold)

    def _update_cooldown_ui(
        self,
        state: str,
        progress: float | None,
        eta_h: float | None,
        *,
        t_cold: float | None = None,
    ) -> None:
        if self._cooldown_status_lbl is None:
            return
        watching = state in ("WATCHING", "FIRED")
        watchdog_active = state in ("WATCHDOG", "WATCHDOG_FIRED")
        # v0.55.6.1 — labels framed around auto-arm policy. DISARMED
        # before any cooldown phase reads as «ожидает фазы», not
        # «не активен», to telegraph that the alarm is healthy and
        # waiting rather than disabled.
        _STATE_LABELS = {
            "DISARMED": "Ожидает фазы захолаживания",
            "ARMED": "Активен (сбор базы...)",
            "WATCHING": "Активен — сторож запущен",
            "FIRED": "ПРЕДУПРЕЖДЕНИЕ: захолаживание не по плану",
            "AUTO_DISARMED": "Захолаживание завершено",
            "WATCHDOG": "Сторож измерения активен",
            "WATCHDOG_FIRED": "Предупреждение: холодная ступень нагревается",
            "UNAVAILABLE": "Недоступен",
        }
        self._cooldown_status_lbl.setText(_STATE_LABELS.get(state, state))
        color = theme.MUTED_FOREGROUND
        if state in ("FIRED", "WATCHDOG_FIRED"):
            color = theme.STATUS_FAULT
        elif state in ("ARMED", "WATCHING", "WATCHDOG"):
            color = theme.ACCENT
        elif state == "AUTO_DISARMED":
            color = theme.STATUS_OK
        self._cooldown_status_lbl.setStyleSheet(f"color: {color};")

        # ETA + progress bar: shown for WATCHING/FIRED; hidden for WATCHDOG modes
        if self._cooldown_eta_lbl is not None:
            if watchdog_active:
                # Show current T11 reading instead of ETA
                self._cooldown_eta_lbl.setVisible(t_cold is not None)
                if t_cold is not None:
                    self._cooldown_eta_lbl.setText(f"Т11: {t_cold:.2f} K")
            else:
                self._cooldown_eta_lbl.setVisible(watching and eta_h is not None)
                if watching and eta_h is not None:
                    self._cooldown_eta_lbl.setText(f"ETA: {eta_h:.1f} ч")

        if self._cooldown_progress is not None:
            self._cooldown_progress.setVisible(watching and progress is not None)
            if watching and progress is not None:
                self._cooldown_progress.setValue(int(progress * 100))

    # v0.55.6.1 — manual arm/disarm click handlers removed; the alarm
    # auto-arms on the cooldown phase transition (engine-side
    # cooldown_alarm tick). Backend ZMQ commands cooldown_alarm.arm /
    # cooldown_alarm.disarm remain in place so smoke tests and the
    # legacy CLI keep working.

    # ------------------------------------------------------------------
    # Enablement
    # ------------------------------------------------------------------

    def _apply_ack_enabled(self) -> None:
        for btn in list(self._v1_ack_buttons) + list(self._v2_ack_buttons):
            try:
                btn.setEnabled(self._connected and not self._read_only)
            except RuntimeError:
                # Button's C++ object already gone (row rebuilt) — prune.
                continue
