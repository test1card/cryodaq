"""Router for F30 Live Query Agent — dispatches QueryIntent to ServiceAdapters."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from cryodaq.agents.assistant.query.schemas import (
    QueryAdapters,
    QueryCategory,
    QueryIntent,
)

if TYPE_CHECKING:
    from cryodaq.core.channel_manager import ChannelManager

logger = logging.getLogger(__name__)


class QueryRouter:
    """Dispatches a classified QueryIntent to the appropriate ServiceAdapter.

    Returns a data dict with the fetched result, or None if dispatch failed.
    The data dict is category-specific and is passed to the format LLM in Phase C.
    """

    def __init__(
        self,
        adapters: QueryAdapters,
        *,
        channel_manager: ChannelManager | None = None,
    ) -> None:
        self._adapters = adapters
        self._channel_manager = channel_manager

    def _resolve_target_channels(self, intent: QueryIntent) -> list[str] | None:
        """Validate and resolve target_channels against current ChannelManager.

        Late binding: reads ChannelManager fresh on every call, picks up renames.
        """
        if not intent.target_channels:
            return None
        if self._channel_manager is None:
            return list(intent.target_channels)
        all_ids = set(self._channel_manager.get_all())
        resolved: list[str] = []
        for raw in intent.target_channels:
            raw_s = raw.strip()
            if raw_s in all_ids:
                resolved.append(raw_s)
                continue
            # Latin→Cyrillic normalization: "T12" → "Т12" (keyboard layout mismatch)
            norm_id = self._channel_manager.normalize_channel_id(raw_s)
            if norm_id != raw_s and norm_id in all_ids:
                resolved.append(norm_id)
                continue
            # F-ChannelLandmarks: consult landmark aliases (Т11/Т12) BEFORE
            # falling through to experiment-level name matching, so the
            # priority promised by the classifier prompt also holds at the
            # resolver layer when Gemma echoes an alias verbatim.
            landmark_id = self._channel_manager.find_by_landmark_alias(raw_s)
            if landmark_id:
                resolved.append(landmark_id)
                continue
            match_id = self._channel_manager.find_by_name(raw_s)
            if match_id:
                resolved.append(match_id)
                continue
            logger.warning("QueryRouter: cannot resolve target_channel %r to known ID", raw)
        return resolved if resolved else None

    async def fetch(
        self,
        intent: QueryIntent,
        query: str,
    ) -> dict[str, Any]:
        """Fetch data for a classified intent. Never raises.

        Returns a dict with category-specific fields. Out-of-scope and unknown
        categories return an empty dict (no data fetch needed — format LLM handles it).
        """
        cat = intent.category
        try:
            if cat == QueryCategory.CURRENT_VALUE:
                return await self._fetch_current_value(intent)
            if cat == QueryCategory.ETA_COOLDOWN:
                return await self._fetch_eta_cooldown()
            if cat == QueryCategory.ETA_VACUUM:
                return await self._fetch_eta_vacuum()
            if cat == QueryCategory.RANGE_STATS:
                return await self._fetch_range_stats(intent)
            if cat == QueryCategory.PHASE_INFO:
                return await self._fetch_phase_info()
            if cat == QueryCategory.ALARM_STATUS:
                return await self._fetch_alarm_status()
            if cat == QueryCategory.COMPOSITE_STATUS:
                return await self._fetch_composite()
            # F33 — read-only archive queries.
            if cat == QueryCategory.ARCHIVE_LIST:
                return await self._fetch_archive_list(intent)
            if cat == QueryCategory.ARCHIVE_DETAIL:
                return await self._fetch_archive_detail(intent, query)
            if cat == QueryCategory.ALARM_HISTORY:
                return await self._fetch_alarm_history(intent)
            # F32 Stage 2 (v0.55.7) — semantic search over RAG corpus.
            if cat == QueryCategory.KNOWLEDGE_QUERY:
                return await self._fetch_knowledge_query(intent, query)
            # Out-of-scope and unknown: no data needed
            return {}
        except Exception as exc:
            logger.warning("QueryRouter.fetch failed for %s: %s", cat.value, exc)
            return {}

    async def _fetch_current_value(self, intent: QueryIntent) -> dict[str, Any]:
        channels = self._resolve_target_channels(intent) or []
        snapshot = self._adapters.broker_snapshot
        readings = {}
        for ch in channels:
            r = await snapshot.latest(ch)
            if r is not None:
                readings[ch] = r
        # Also include age
        ages = {}
        for ch in channels:
            age = await snapshot.latest_age_s(ch)
            if age is not None:
                ages[ch] = age
        return {"readings": readings, "ages_s": ages, "channels": channels}

    async def _fetch_eta_cooldown(self) -> dict[str, Any]:
        eta = await self._adapters.cooldown.eta()
        return {"cooldown_eta": eta}

    async def _fetch_eta_vacuum(self) -> dict[str, Any]:
        eta = await self._adapters.vacuum.eta_to_target(1e-6)
        # Also get current pressure from snapshot
        snapshot = self._adapters.broker_snapshot
        all_ch = await snapshot.latest_all()
        current_p = None
        for ch, reading in all_ch.items():
            if "pressure" in ch.lower() or "mbar" in ch.lower():
                current_p = reading.value
                if eta is not None:
                    eta.current_mbar = current_p
                break
        return {"vacuum_eta": eta, "current_pressure": current_p}

    async def _fetch_range_stats(self, intent: QueryIntent) -> dict[str, Any]:
        channels = self._resolve_target_channels(intent) or []
        window = intent.time_window_minutes or 60
        results = {}
        for ch in channels:
            stats = await self._adapters.sqlite.range_stats(ch, window)
            if stats is not None:
                results[ch] = stats
        # If no specific channels, try snapshot for pressure as default range
        if not channels:
            all_ch = await self._adapters.broker_snapshot.latest_all()
            for ch in all_ch:
                if "pressure" in ch.lower() or "mbar" in ch.lower():
                    stats = await self._adapters.sqlite.range_stats(ch, window)
                    if stats is not None:
                        results[ch] = stats
                    break
        return {"range_stats": results, "window_minutes": window}

    async def _fetch_phase_info(self) -> dict[str, Any]:
        status = await self._adapters.experiment.status()
        return {"experiment_status": status}

    async def _fetch_alarm_status(self) -> dict[str, Any]:
        result = await self._adapters.alarms.active()
        return {"alarm_result": result}

    async def _fetch_composite(self) -> dict[str, Any]:
        composite = await self._adapters.composite.status()
        return {"composite_status": composite}

    # ------------------------------------------------------------------
    # F33 — archive queries
    # ------------------------------------------------------------------

    @staticmethod
    def _days_from_intent(intent: QueryIntent, default_days: int = 7) -> int:
        """Convert ``time_window_minutes`` (the IntentClassifier's only time
        knob) to whole days, defaulting to ``default_days`` when absent.
        Minimum window is 1 day so the LLM cannot ask for "0 days"."""
        win = intent.time_window_minutes
        if win is None or win <= 0:
            return default_days
        return max(1, int(win) // 1440 or 1)

    async def _fetch_archive_list(self, intent: QueryIntent) -> dict[str, Any]:
        archive = self._adapters.archive
        if archive is None:
            return {"archive_list": None}
        days = self._days_from_intent(intent)
        result = await archive.list_recent(days=days)
        return {"archive_list": result}

    async def _fetch_archive_detail(
        self, intent: QueryIntent, query: str
    ) -> dict[str, Any]:
        archive = self._adapters.archive
        if archive is None:
            return {"archive_detail": None}
        # Heuristic: the IntentClassifier may surface an experiment id via
        # ``quantity`` or as the only entry in ``target_channels`` (the LLM
        # sometimes treats it as a "channel"). Fallback to None — adapter
        # will return None, format prompt frames it as "детали не найдены".
        candidate = (intent.quantity or "").strip()
        if not candidate and intent.target_channels:
            candidate = intent.target_channels[0].strip()
        if not candidate:
            return {"archive_detail": None, "query": query}
        result = await archive.get_detail(candidate)
        return {"archive_detail": result, "experiment_id": candidate}

    async def _fetch_alarm_history(self, intent: QueryIntent) -> dict[str, Any]:
        archive = self._adapters.archive
        if archive is None:
            return {"alarm_history": None}
        days = self._days_from_intent(intent)
        result = await archive.alarm_history_summary(days=days)
        return {"alarm_history": result}

    # ------------------------------------------------------------------
    # F32 Stage 2 (v0.55.7) — knowledge query
    # ------------------------------------------------------------------

    async def _fetch_knowledge_query(
        self, intent: QueryIntent, query: str
    ) -> dict[str, Any]:
        """Run semantic search over the RAG corpus.

        ``query`` is preferred over ``intent.quantity`` because the original
        operator phrasing carries far more retrieval signal than the
        classifier's brief paraphrase. ``target_source_kind`` (when present)
        narrows the LanceDB ``WHERE`` clause to a single corpus kind.
        """
        adapter = self._adapters.rag
        if adapter is None or not getattr(adapter, "is_available", False):
            return {"knowledge_query": None, "query": query}
        result = await adapter.search(
            query,
            source_kind=intent.target_source_kind,
        )
        return {"knowledge_query": result, "query": query}
